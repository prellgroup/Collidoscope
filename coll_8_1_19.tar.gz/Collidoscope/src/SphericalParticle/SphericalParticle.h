/******* SphericalParticle.h ********/
#ifndef SPHERICAL_PARTICLE_H
#define SPHERICAL_PARTICLE_H

#include "Particle.h"

using namespace std;

class SphericalParticle : public Particle {
  private:
    double         pol;                   //polarizability volume
  public:
                   SphericalParticle();
    void           SetInfo(GasFileData*);
    double         GetPol();
    virtual void   FindForce();
    virtual double FindPotential(double*);
};

#endif

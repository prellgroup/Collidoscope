/************ Parameters.cpp ************/
#include "Parameters.h"
#include "StringManip.h" // ToLower
#include "Definitions.h" // OS definitions

#include <sstream>       // stringstream
#include <iostream>      // cerr, endl;
#include <cstdio>        // fprintf, stderr
#include <cstdlib>       // exit
#include <cstring>       // strlen, strcmp

using namespace std;

Parameters * Parameters::instance = NULL;

Parameters::Parameters() {
    settingsPresent.reset();
}

Parameters::~Parameters() {
//    cerr << "deleting the Parameters." << endl;
}

Parameters * Parameters::Get() {
    if(Parameters::instance == NULL) Parameters::instance = new Parameters;
    return Parameters::instance;
}

int Parameters::GetAppendNum(string infoFileName) {
    int numAppended = 0;
    stringstream tempFile(infoFileName);
    while(FileExists(tempFile.str())) {
        numAppended++;
        tempFile.str("");
        tempFile << infoFileName << "_" << numAppended;
        if(numAppended >= 20) {
            fprintf(stderr, "Could not open file %s : Please remove other instances of this file.\n",infoFileName.c_str());
            return -1;
        }
    }
    return numAppended;
}

//convert a string into its corresponding enum value
void Parameters::DetermineIntegrationMethod(string methodString) {
    if(ToLower(methodString).find("euler") != string::npos) {
        method = IM_EULER;
    } else if(ToLower(methodString).find("rk4") != string::npos) {
        method = IM_RK4;
    } else {
        method = IM_UNKNOWN;
    }
}

//convert a string into its corresponding enum value
void Parameters::DetermineParticleType(string particleType) {
    if(ToLower(particleType).find("spherical") != string::npos) {
        pType = PT_SPHERICAL;
    } else if(ToLower(particleType).find("diatomic") != string::npos) {
        pType = PT_DIATOMIC;
    } else {
        pType = PT_UNKNOWN;
    }
}

void Parameters::SetMode(string arg) {
    mode.reset();
    if(ToLower(arg).find("ccs") != string::npos) {
        mode.set(ALG_CROSS_SECTION);
    } else if(ToLower(arg).find("place") != string::npos) {
        mode.set(ALG_CHARGE_PLACER);
    } else if(ToLower(arg).find("all") != string::npos) {
        mode.set(ALG_CROSS_SECTION);
        mode.set(ALG_CHARGE_PLACER);
    } else {
        mode.set(ALG_UNKNOWN);
    }
}

bool Parameters::ChangeFileNames() {
    char   tempInfoFile[256] = "tmpFileName";   //Filename used to determine what number to append to output files
    bool   appendNum         = false;           //Whether or not a number should be appended to output files

    int numAppended = GetAppendNum(infoFileName);
    if(numAppended == -1) return false;

    if(numAppended != 0) {
        appendNum = true;

        stringstream newTrajName,newInfoName,newEnergyName;
        newTrajName << trajFileName << "_" << numAppended;
        newInfoName << infoFileName << "_" << numAppended;
        newEnergyName << energyFileName << "_" << numAppended;

        trajFileName = newTrajName.str();
        infoFileName = newInfoName.str();
        energyFileName = newEnergyName.str();
   }
   return true;
}

bool Parameters::FileExists(string fileName) {
#if defined(ON_LINUX)
	return access(fileName.c_str(), F_OK) == 0;
#elif defined(ON_WINDOWS)
	return PathFileExists(fileName.c_str());
#else
    cerr << "Unknown Operating system!" << endl;
    exit(-1);
#endif
}

//determine the output booleans based on the input string
void Parameters::DetermineTrajOutput(string trajString) {
    if(ToLower(trajString).find("none") != string::npos) {
        trajSetting.reset();
    } else if(ToLower(trajString).find("split") != string::npos) {
        trajSetting.set(TO_OUTPUT);
    } else if(ToLower(trajString).find("combined") != string::npos) {
        trajSetting.set(TO_OUTPUT).set(TO_COMBINED);
    } else {
        trajSetting.set(TO_UNKNOWN);
    }
}

string Parameters::GetpTypeString() {
  switch(pType) {
    case PT_SPHERICAL:
      return "Spherical";
    case PT_DIATOMIC:
      return "Diatomic";
    case PT_UNKNOWN:
      return "Unknown";
    default:
      return "Misformatted Particle Type";
    }
}

string Parameters::GetMethodString() {
  switch(method) {
    case IM_EULER:
      return "Euler";
    case IM_RK4:
      return "RK4";
    case IM_UNKNOWN:
      return "Unknown";
    default:
      return "Misformatted method";
  }
}

string Parameters::GetTrajSettingString() {
    if(trajSetting.test(TO_UNKNOWN)) return "Unknown setting";
    if(trajSetting.test(TO_OUTPUT)) {
        if(trajSetting.test(TO_COMBINED)) return "Combined";
        return "Split";
    }
    return "None";
}

string Parameters::GetModeString() {
    if( mode.test(ALG_CROSS_SECTION) &&  mode.test(ALG_CHARGE_PLACER)) return "all";
    if(!mode.test(ALG_CROSS_SECTION) &&  mode.test(ALG_CHARGE_PLACER)) return "place";
    if( mode.test(ALG_CROSS_SECTION) && !mode.test(ALG_CHARGE_PLACER)) return "CCS";
    if(!mode.test(ALG_CROSS_SECTION) && !mode.test(ALG_CHARGE_PLACER)) return "none";
    return "unknown mode";
}

// Parse options given on the command line. Return false if an invalid Settings Input File was given
bool Parameters::SetFromCommandLine(int argc, char ** argv) {
    for(int i = 1; i < argc-1; ++i) {
        bool argIsOption = true;
        if(       string(argv[i]) == "-C"    && isNumeric(argv[i+1])) {
            settingsPresent.set(CHARGE);
            charge = atof(argv[i+1]);
        } else if(string(argv[i]) == "-e"    && isNumeric(argv[i+1])) {
            settingsPresent.set(ENSTATES);
            enStates = atoi(argv[i+1]);
        } else if(string(argv[i]) == "-eps"  && isNumeric(argv[i+1])) {
            settingsPresent.set(EPSILON);
            epsilon = atof(argv[i+1]);
        } else if(string(argv[i]) == "-fa"   && argv[i+1][0] != '-') {
            settingsPresent.set(AFFINITYNAME);
            affinityFileName = argv[i+1];
        } else if(string(argv[i]) == "-fc"   && argv[i+1][0] != '-') {
            settingsPresent.set(COORDNAME);
            coordFileName = argv[i+1];
        } else if(string(argv[i]) == "-fg"   && argv[i+1][0] != '-') {
            settingsPresent.set(GEOMETRYNAME);
            geometryFileName = argv[i+1];
        } else if(string(argv[i]) == "-fp"   && argv[i+1][0] != '-') {
            settingsPresent.set(GASNAME);
            gasParamFileName = argv[i+1];
        } else if(string(argv[i]) == "-fs"   && argv[i+1][0] != '-') {
            if(!FileExists(argv[i+1])) {
                cerr << "Could not find a file at " << argv[i+1] << ". Please choose a new Settings Input File." << endl;
                return false;
            }
            settingsPresent.set(SETTINGSNAME);
            settingsFileName = argv[i+1];
        } else if(string(argv[i]) == "-m"    && isNumeric(argv[i+1])) {
            settingsPresent.set(MINEN);
            minEn = atof(argv[i+1]);
        } else if(string(argv[i]) == "-M"    && isNumeric(argv[i+1])) {
            settingsPresent.set(MAXEN);
            maxEn = atof(argv[i+1]);
        } else if(string(argv[i]) == "-mode" && argv[i+1][0] != '-') {
            settingsPresent.set(MODE);
            SetMode(argv[i+1]);
        } else if(string(argv[i]) == "-int" && argv[i+1][0] != '-') {
            settingsPresent.set(INTEGRATOR);
            DetermineIntegrationMethod(argv[i+1]);    
        } else if(string(argv[i]) == "-oe"   && argv[i+1][0] != '-') {
            settingsPresent.set(ENERGYNAME);
            energyFileName = argv[i+1];
        } else if(string(argv[i]) == "-oi"   && argv[i+1][0] != '-') {
            settingsPresent.set(INFONAME);
            infoFileName = argv[i+1];
        } else if(string(argv[i]) == "-ot"   && argv[i+1][0] != '-') {
            settingsPresent.set(TRAJNAME);
            trajFileName = argv[i+1];
        } else if(string(argv[i]) == "-p"    && argv[i+1][0] != '-') {
            settingsPresent.set(PTYPE);
            DetermineParticleType(argv[i+1]);
            //if(strcmp(argv[i+1], "Spherical") == 0) pType = PT_SPHERICAL;
            //else if(strcmp(argv[i+1], "Diatomic") == 0)  pType = PT_DIATOMIC;
            //else                                    pType = PT_UNKNOWN;
        } else if(string(argv[i]) == "-T"    && isNumeric(argv[i+1])) {
            settingsPresent.set(TEMP);
            temp = atof(argv[i+1]);
        } else if(string(argv[i]) == "-traj"    && argv[i+1][0] != '-') {
            settingsPresent.set(TRAJSETTING);
            DetermineTrajOutput(argv[i+1]);
        } else {
            argIsOption = false;
            cerr << "Unknown or invalid command line argument: " << argv[i] << endl;
        }
        //skip value (next argument) if a valid option was found
        if(argIsOption) ++i;
    }
    if(!settingsPresent.test(SETTINGSNAME)) {
        settingsFileName = "inputFiles/input.txt";
    }
    return true;
}

bool Parameters::AreValid() {
    bool allValid = true;
    if(!settingsPresent.test(MODE)) {
        cerr << "No default algorithm chosen. Defaulting to \"all\"." << endl;
        SetMode("all");
    } else if(mode.test(ALG_UNKNOWN)) {
        cerr << "Unknown algorithm option given." << endl;
        allValid = false;
    }
    if(!settingsPresent.test(TEMP)) {
        cerr << "No default temperature specified in " << settingsFileName << ", defaulting to 298.15." << endl;
        temp = 298.15;
    } else if(temp < 10) {
        cerr << "Temperature (" << temp << ") below the allowed limit. Must be greater than 10 K." << endl;
        allValid = false;
    }
    if(!settingsPresent.test(CHARGE)) {
        cerr << "No default charge specified in " << settingsFileName << ", defaulting to 0." << endl;
        charge = 0;
    }
    if(!settingsPresent.test(COORDNAME)) {
        cerr << "No default coordinate file specified in " << settingsFileName;
        cerr << ", defaulting to coordinateFiles/ondansetron.txt." << endl;
        coordFileName = "coordinateFiles/ondansetron.txt";
    }
    if(!FileExists(coordFileName)) {
        cerr << "Could not find a file at " << coordFileName << ". Please choose a new Coordinate Input File." << endl;
        allValid = false;
    }
    if(!settingsPresent.test(INFONAME)) {
        cerr << "No default information output file specified in " << settingsFileName;
        cerr << ", defaulting to outputFiles/default.info." << endl;
        infoFileName = "outputFiles/default.info";
    }
    if(mode.test(ALG_CHARGE_PLACER)) {
        if(!settingsPresent.test(ENERGYNAME)) {
            cerr << "No default energy output file chosen. Defaulting to \"outputFiles/output.ener\"" << endl;
            energyFileName = "outputFiles/output.ener";
        }
        if(!settingsPresent.test(EPSILON)) {
            cerr << "No default epsilon value chosen. Defaulting to 4" << endl;
            epsilon = 4;
        } else if(epsilon < 0) {
            cerr << "Relative permittivity (" << epsilon << ") must be positive." << endl;
            allValid = false;
        }
        if(!settingsPresent.test(AFFINITYNAME)) {
            cerr << "No default Affinity Input File chosen. Defaulting to \"inputFiles/affinity.txt\"" << endl;
            affinityFileName = "inputFiles/affinity.txt";
        }
        if(!FileExists(affinityFileName)) {
            cerr << "Could not find a file at " << affinityFileName << ". Please choose a new Affinity Input File." << endl;
            allValid = false;
        }
    }
    if(mode.test(ALG_CROSS_SECTION)) {
        if(!settingsPresent.test(MINEN)) {
            cerr << "No default minimum energy specified in " << settingsFileName << ", defaulting to 0.5." << endl;
            minEn = 0.5;
        } else if(minEn < 0) {
            cerr << "Minimum energy (" << minEn << ") must be positive." << endl;
            allValid = false;
        }
        if(!settingsPresent.test(MAXEN)) {
            cerr << "No default maximum energy specified in " << settingsFileName << ", defaulting to 8." << endl;
            maxEn = 8;
        } else if(maxEn < 0) {
            cerr << "Maximum energy (" << maxEn << ") must be positive." << endl;
            allValid = false;
        }
        if(!settingsPresent.test(ENSTATES)) {
            cerr << "No default energy states specified in " << settingsFileName << ", defaulting to 4." << endl;
            enStates = 4;
        } else if(enStates < 0) {
            cerr << "The number of energy states (" << enStates << ") must be a positive integer." << endl;
            allValid = false;
        }
        if(!settingsPresent.test(PTYPE)) {
            cerr << "No default particle type specified in " << settingsFileName << ", defaulting to spherical." << endl;
            pType = PT_SPHERICAL;
        } else if(pType == PT_UNKNOWN) {
            cerr << "Unknown Particle Type entered." << endl;
            allValid = false;
        }
        if(!settingsPresent.test(INTEGRATOR)) {
            cerr << "No integration method specified in " << settingsFileName << ", defaulting to Euler." << endl;
            method = IM_EULER;
        } else if(method == IM_UNKNOWN) {
            cerr << "Unknown integration method entered." << endl;
            allValid = false;
        }
        if(!settingsPresent.test(TRAJSETTING)) {
            cerr << "No trajectory output setting chosen. Defaulting to \"none\"" << endl;
            DetermineTrajOutput("none");
        } else if(trajSetting.test(TO_UNKNOWN)) {
            cerr << "Unknown trajectory output setting." << endl;
            allValid = false;
        }
        if(!settingsPresent.test(GEOMETRYNAME)) {
            cerr << "No default Geometry Input File chosen. Defaulting to \"inputFiles/Geometry.txt\"" << endl;
            geometryFileName = "inputFiles/Geometry.txt";
        }
        if(!FileExists(geometryFileName)) {
            cerr << "Could not find a file at " << geometryFileName << ". Please choose a new Geometry Input File." << endl;
            allValid = false;
        }
        if(!settingsPresent.test(TRAJNAME)) {
            cerr << "No default trajectory output file specified in " << settingsFileName << ", defaulting to outputFiles/default.traj." << endl;
            trajFileName = "outputFiles/default.traj";
        }
        if(!settingsPresent.test(GASNAME)) {
            cerr << "No default Gas Parameter input File chosen. Defaulting to \"inputFiles/He.gas\"" << endl;
            gasParamFileName = "inputFiles/He.gas";
        }
        if(!FileExists(gasParamFileName)) {
            cerr << "Could not find a file at " << gasParamFileName << ". Please choose a new Gas Parameter Input File." << endl;
        }

        //Ensure that max/min energies make sense with the number of energy states
        if(enStates > 1 && minEn == maxEn) {
            cerr << "Minimum and Maximum energies are equal, but " << enStates << " energy states are requested";
            cerr << ". Changing to 1 energy state." << endl;
            enStates = 1;
        } else if(enStates == 1 && minEn != maxEn) {
            cerr << "Requested 1 energy state, but chose energies in the range of " << minEn << "-" << maxEn;
            cerr << ". Setting maximum energy to " << minEn << "." << endl;
            maxEn = minEn;
        }
    }
    return allValid;
}

bitset<18> & Parameters::GetSettingsPresent() {
    return settingsPresent;
}

bitset<3> & Parameters::GetTrajSetting() {
    return trajSetting;
}

bitset<3> & Parameters::GetMode() {
    return mode;
}

string & Parameters::GetSettingsFileName() {
    return settingsFileName;
}

string & Parameters::GetGeometryFileName() {
    return geometryFileName;
}

string & Parameters::GetAffinityFileName() {
    return affinityFileName;
}

string & Parameters::GetGasParamFileName() {
    return gasParamFileName;
}

double & Parameters::GetCharge() {
    return charge;
}

double & Parameters::GetMinEn() {
    return minEn;
}

double & Parameters::GetMaxEn() {
    return maxEn;
}

int & Parameters::GetEnStates() {
    return enStates;
}

double & Parameters::GetTemp() {
    return temp;
}

ParticleType Parameters::GetPType() {
    return pType;
}

IntegrationMethod Parameters::GetMethod() {
    return method;
}

string & Parameters::GetCoordFileName() {
    return coordFileName;
}

string & Parameters::GetInfoFileName() {
    return infoFileName;
}

string & Parameters::GetTrajFileName() {
    return trajFileName;
}

double & Parameters::GetEpsilon() {
    return epsilon;
}

string & Parameters::GetEnergyFileName() {
    return energyFileName;
}

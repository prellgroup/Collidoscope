#include "Parameters.h"

using namespace std;

int main() {
    Parameters * p = Parameters::Get();
    p->DetermineTrajOutput("SpLit");
    if(!p->GetTrajSetting().test(TO_OUTPUT) || p->GetTrajSetting().test(TO_COMBINED) || p->GetTrajSetting().test(TO_UNKNOWN)) return -1;
    
    p->DetermineTrajOutput("ComBineD");
    if(p->GetTrajSetting().test(TO_OUTPUT) || !p->GetTrajSetting().test(TO_COMBINED) || p->GetTrajSetting().test(TO_UNKNOWN)) return -1;

    p->DetermineTrajOutput("NoNE");
    if(p->GetTrajSetting().test(TO_OUTPUT) || p->GetTrajSetting().test(TO_COMBINED) || p->GetTrajSetting().test(TO_UNKNOWN)) return -1;

    p->DetermineTrajOutput("WhAt");
    if(p->GetTrajSetting().test(TO_OUTPUT) || p->GetTrajSetting().test(TO_COMBINED) || !p->GetTrajSetting().test(TO_UNKNOWN)) return -1;
    return 1;
}

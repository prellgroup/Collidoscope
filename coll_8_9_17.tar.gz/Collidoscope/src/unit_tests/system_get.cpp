#include "System.h"

using namespace std;

int main() {
    System * sys = System::Get();
    if(sys == NULL) return -1;
    return 1;
}

/******* DiatomicParticle.h ********/
#ifndef DIATOMIC_PARTICLE_H
#define DIATOMIC_PARTICLE_H

#include "Particle.h"

using namespace std;

class DiatomicParticle : public Particle {
  private:
    double         axialPol;                   //polarizability volume
    double         radialPol;
    double         bondLength;
    double         potential;
  public:
                   DiatomicParticle();
    void           SetInfo(GasFileData*);
    double         GetPol();
    virtual void   FindForce();
    double       * FindForceDir(double*, double*);
    virtual double FindPotential(double*);
    double         FindPotentialDir(double*,double*);
};

#endif

/************* SettingsFileReader.cpp *************/
#include "SettingsFileReader.h" // Function declarations
#include "Parameters.h"         // Parameters data type
#include "StringManip.h"        // ToLower, CleanString
#include <fstream>              // ifstream
#include <iostream>             // fail, cerr
#include <string>               // find, npos, substr, erase, c_str
#include <cstring>              // size_t, strcmp
#include <sstream>              // stringstream
#include <cstdlib>              // atof, atoi

SettingsFileReader::SettingsFileReader(string fileName) : FileReader(fileName) {};

SettingsFileReader::~SettingsFileReader() {
    //cerr << "deleting Settings File reader" << endl;
}

//Read each line of the fileName file, storing to variables as needed
bool SettingsFileReader::Read() {
    Parameters * params = Parameters::Get();
    ifstream inputFile;
    inputFile.open(fileName.c_str());
    if(inputFile.fail()) {
        cerr << "Settings Input File " << fileName << " did not open." << endl;
        return false;
    }

    string line;
    getline(inputFile,line);
    string lowerCaseLine = ToLower(line);
    while(!inputFile.eof()) {
        if(line[0] == '#' || line == "") {
            getline(inputFile,line);
            lowerCaseLine = ToLower(line);
            continue;
        }

        if(!params->GetSettingsPresent().test(CHARGE) && (lowerCaseLine.find("net charge") != string::npos)) {
            if(ExtractDoubleAfter("=", line, params->GetCharge())) params->GetSettingsPresent().set(CHARGE);
        } else if(!params->GetSettingsPresent().test(MINEN) && (lowerCaseLine.find("minimum energy") != string::npos)) {
            if(ExtractDoubleAfter("=", line, params->GetMinEn())) params->GetSettingsPresent().set(MINEN);
        } else if(!params->GetSettingsPresent().test(MAXEN) && (lowerCaseLine.find("maximum energy") != string::npos)) {
            if(ExtractDoubleAfter("=", line, params->GetMaxEn())) params->GetSettingsPresent().set(MAXEN);
        } else if(!params->GetSettingsPresent().test(ENSTATES) && (lowerCaseLine.find("energy states") != string::npos)) {
            if(ExtractIntAfter("=", line, params->GetEnStates())) params->GetSettingsPresent().set(ENSTATES);
        } else if(!params->GetSettingsPresent().test(TEMP) && (lowerCaseLine.find("temperature") != string::npos)) {
            if(ExtractDoubleAfter("=", line, params->GetTemp())) params->GetSettingsPresent().set(TEMP);
        } else if(!params->GetSettingsPresent().test(PTYPE) && (lowerCaseLine.find("particle type") != string::npos)) {
            string pT;
            if(ParseStringAfter(line, ':', pT)) {
                params->DetermineParticleType(CleanString(pT));
                params->GetSettingsPresent().set(PTYPE);
            }
        } else if(!params->GetSettingsPresent().test(INTEGRATOR) && (lowerCaseLine.find("integration method") != string::npos)) {
            string iM;
            if(ParseStringAfter(line, ':', iM)) {
                params->DetermineIntegrationMethod(CleanString(iM));
                params->GetSettingsPresent().set(INTEGRATOR);
            }
        } else if(!params->GetSettingsPresent().test(COORDNAME) && (lowerCaseLine.find("coordinate input file") != string::npos)) {
            if(ParseStringAfter(line, ':', params->GetCoordFileName())) {
                CleanString(params->GetCoordFileName());
                params->GetSettingsPresent().set(COORDNAME);
            }
        } else if(!params->GetSettingsPresent().test(TRAJSETTING) && (lowerCaseLine.find("trajectory setting") != string::npos)) {
            string trajOutputSetting;
            if(ParseStringAfter(line, ':', trajOutputSetting)) {
                params->DetermineTrajOutput(CleanString(trajOutputSetting));
                params->GetSettingsPresent().set(TRAJSETTING);
            }
        } else if(!params->GetSettingsPresent().test(INFONAME) && (lowerCaseLine.find("information output") != string::npos)) {
            if(ParseStringAfter(line, ':', params->GetInfoFileName())) {
                CleanString(params->GetInfoFileName());
                params->GetSettingsPresent().set(INFONAME);
            }
        } else if(!params->GetSettingsPresent().test(TRAJNAME) && (lowerCaseLine.find("trajectory output") != string::npos)) {
            if(ParseStringAfter(line, ':', params->GetTrajFileName())) {
                CleanString(params->GetTrajFileName());
                params->GetSettingsPresent().set(TRAJNAME);
            }
        } else if(!params->GetSettingsPresent().test(MODE) && (lowerCaseLine.find("algorithm") != string::npos)) {
            string mode;
            if(ParseStringAfter(line, ':', mode)) {
                params->GetSettingsPresent().set(MODE);
                params->SetMode(mode);
            }
        } else if(!params->GetSettingsPresent().test(EPSILON) && (lowerCaseLine.find("epsilon") != string::npos)) {
            if(ExtractDoubleAfter("=", line, params->GetEpsilon())) {
                params->GetSettingsPresent().set(EPSILON);
            }
        } else if(!params->GetSettingsPresent().test(ENERGYNAME) && (lowerCaseLine.find("energy output file") != string::npos)) {
            if(ParseStringAfter(line, ':', params->GetEnergyFileName())) {
                params->GetSettingsPresent().set(ENERGYNAME);
                CleanString(params->GetEnergyFileName());
            }
        } else if(!params->GetSettingsPresent().test(AFFINITYNAME) && (lowerCaseLine.find("affinity input file") != string::npos)) {
            if(ParseStringAfter(line, ':', params->GetAffinityFileName())) {
                params->GetSettingsPresent().set(AFFINITYNAME);
                CleanString(params->GetAffinityFileName());
            }
        } else if(!params->GetSettingsPresent().test(GEOMETRYNAME) && (lowerCaseLine.find("geometry input file") != string::npos)) {
            if(ParseStringAfter(line, ':', params->GetGeometryFileName())) {
                params->GetSettingsPresent().set(GEOMETRYNAME);
                CleanString(params->GetGeometryFileName());
            }
        } else if(!params->GetSettingsPresent().test(GASNAME) && (lowerCaseLine.find("gas parameter input file") != string::npos)) {
            if(ParseStringAfter(line, ':', params->GetGasParamFileName())) {
                params->GetSettingsPresent().set(GASNAME);
                CleanString(params->GetGasParamFileName());
            }
        } else {
            cerr << "ignored line in " << params->GetSettingsFileName();
            cerr << " - either unknown line, or parameter has already been set):" << endl << line << endl;
        }
        getline(inputFile,line);
        lowerCaseLine = ToLower(line);
    }
    inputFile.close();
    return true;
}

/************* GeometryFileData.h **************/
#ifndef GEOMETRY_FILE_DATA_H
#define GEOMETRY_FILE_DATA_H

#include "FileData.h"

class GeometryFileData : public FileData {
  public:
    double * vantages;
    int      vantagePoints;
};

#endif

/**************** DiatomicParticleData.h *********/
#include "GasFileData.h"

using namespace std;

class DiatomicParticleData : public GasFileData {
  private:
  public:
    GasFileData * Copy();
    double axialPol;
    double bondLength;
    double radialPol;
};

/************ System.cpp **********/
#include "System.h"
#include "Parameters.h"
#include "SphericalParticle.h"
#include "DiatomicParticle.h"
#include "TrajFileWriter.h"
#include "Euler_Int.h"  // Euler integrator class
#include "RK4_Int.h"    // RK4 integrator class
#include <cfloat>       // DBL_MAX, DBL_MIN
#include <climits>      // INT_MIN, INT_MAX
#include <omp.h>        // openmp
#include <cmath>        // all of the math functions
#include <iostream>     // cerr, endl
#include <list>         // list data structure
#include <cstdio>
#include <ctime>        // clock
#include <algorithm>    // max, min

#include <fstream>

#ifdef COMPILED_WITH_MPI
#include "mpi.h"
#endif

using namespace std;

System * System::instance = NULL;
const double System::R    = 8.3144621;      // Gas Law Constant      (J/(mol*K))
const double System::rCarbon = 1.707810065; // Carbon-Helium VdW radius (used in impact parameter spacing)

System::System () {
    //Set default values for parameters
    minVel = 0.5;
    maxVel = 8.0;
    deltaVel = 2.5;
    numThreads = omp_get_max_threads();
    //numThreads = 4;
    TS   = NULL;
    m    = NULL;
    ES   = NULL;
    partInt = NULL;
    VP   = NULL;
    s    = NULL;
}

System::~System() {
//cerr << "deleting the System." << endl;
    if(m             != NULL) delete    m;
    if(ES            != NULL) delete [] ES;
    if(VP            != NULL) delete [] VP;
    if(TS            != NULL) delete [] TS;
    if(partInt       != NULL) delete [] partInt;
    if(s             != NULL) DeleteSummary();
    if(partInfo      != NULL) delete    partInfo;
}

void System::CreateSummary() {
    int enStates = Parameters::Get()->GetEnStates();
    s                 = new Summary;
    s->enStateAvgCS   = new double[enStates];
    s->enRatioAvg     = new double[enStates];
    s->enRatioMax     = new double[enStates];
    s->enRatioMin     = new double[enStates];
    s->enRatioStdev   = new double[enStates];
    s->enRatioSumSq   = new double[enStates];
    s->enStateSuccess = new int[enStates];
    s->enStateSkipped = new int[enStates];
    s->enStateRerun   = new int[enStates];
    s->enStateOmitted = new int[enStates];
    s->stepsMax       = new int[enStates];
    s->stepsMin       = new int[enStates];
    s->stepsAvg       = new double[enStates];
}

void System::DeleteSummary() {
    if(s->enStateAvgCS   != NULL) delete [] s->enStateAvgCS;
    if(s->enRatioAvg     != NULL) delete [] s->enRatioAvg;
    if(s->enRatioMax     != NULL) delete [] s->enRatioMax;
    if(s->enRatioMin     != NULL) delete [] s->enRatioMin;
    if(s->enRatioStdev   != NULL) delete [] s->enRatioStdev;
    if(s->enRatioSumSq   != NULL) delete [] s->enRatioSumSq;
    if(s->enStateSuccess != NULL) delete [] s->enStateSuccess;
    if(s->enStateSkipped != NULL) delete [] s->enStateSkipped;
    if(s->enStateRerun   != NULL) delete [] s->enStateRerun;
    if(s->enStateOmitted != NULL) delete [] s->enStateOmitted;
    if(s->stepsMax       != NULL) delete [] s->stepsMax;
    if(s->stepsMin       != NULL) delete [] s->stepsMin;
    if(s->stepsAvg       != NULL) delete [] s->stepsAvg;
    if(s                 != NULL) delete    s;
}
System * System::Get() {
    if(System::instance == NULL) System::instance = new System;
    return System::instance;
}

void System::outputPercentage(string status) {
    int total = 0;
    for(int i = 0; i < totNumParticles; ++i) {
        if(TS[i].trajSuccess || TS[i].trajOmitted) ++total;
    }
    fprintf(stderr, "%s %.3lf %%processed           \r", status.c_str(), 100*(double)total/totNumParticles);
}

void System::SetParams() {
    Parameters * params = Parameters::Get();

    RT     = params->GetTemp()*R;
    minVel = sqrt(params->GetMinEn());
    maxVel = sqrt(params->GetMaxEn());

    if(params->GetEnStates() > 1) deltaVel = (maxVel-minVel)/(double)(params->GetEnStates()-1);
    else                     deltaVel = 1;

    if(ES != NULL) delete [] ES;
    ES = new EnergyState[params->GetEnStates()];
}

void System::AddMolecule(CoordinateFileData * molOut) {
    Parameters * params = Parameters::Get();
    if(m != NULL) delete m;
    m     = new Molecule(molOut);

    //scale distance between trajectories based on the number of atoms
    dist    = rCarbon * pow((double)m->GetNumAtoms()/100, (double)1/5);
}

bool System::SetMoleculeProperties(GasFileData * gas) {
    if(!m->SetAtomProperties(gas)) return false;
    partInfo = gas->Copy();

    mu = 1/(1/gas->mass+1/m->GetMass())/1000;
    bMax    = m->GetRmax() + 15;
    numTraj = (int)ceil(bMax/dist);        //Number of trajectories to run from center to bMax
    totNumTraj1D = 2*numTraj + 1;
    totNumTraj2D = totNumTraj1D * totNumTraj1D;
    return true;
}

void System::Print() {
    cerr << "System at " << this << ":" << endl;
    cerr << "\tbMax        = " << bMax << endl;
    cerr << "\tmu          = " << mu << endl;
    cerr << "\tdist        = " << dist << endl;
    cerr << "\tnumTraj     = " << numTraj << endl;
    cerr << "\tnumVantages = " << numVantages << endl;
    cerr << "\tminVel      = " << minVel << endl;
    cerr << "\tmaxVel      = " << maxVel << endl;
    cerr << "\tdeltaVel    = " << deltaVel << endl;

    m->Print();
}

Molecule * System::GetMolecule() {
    return m;
}

void System::CreateVantagePoints(GeometryFileData * GeoOutput) {
    if(GeoOutput->vantagePoints > 0) {
        numVantages = GeoOutput->vantagePoints;
        if(VP != NULL) delete [] VP;
        VP = new VantagePoint[numVantages];

        for(int i = 0; i < numVantages; i++)
            VP[i].SetBasisVectorDirection(&GeoOutput->vantages[3*i]);
    }

}

//This is the last step to prepare the system for simulation, after all
//input files are read and stored in the system
void System::DeriveInformation() {
    Parameters * params = Parameters::Get();
    for(int i = 0; i < params->GetEnStates(); ++i) ES[i].SetEnParams((minVel+deltaVel*i)*sqrt(2*RT/mu));

    if( minVel*sqrt(2*RT/mu) < 400) {
        cerr << "Low speeds detected! Results may be inaccurate!" << endl;
    }

    for(int i = 0; i < numVantages; i++) VP[i].ScaleBasisVectors(3*bMax);

    totTrajectories = params->GetEnStates() * numVantages * totNumTraj2D;
}

double System::GetCrossSection() {
    Parameters * params = Parameters::Get();
    Integrator * Int;
    if(params->GetMethod() == IM_EULER) Int = new Euler_Int;
    else if(params->GetMethod() == IM_RK4) Int = new RK4_Int;
    else {
        cerr << "Bad integration method" << endl;
        return -1;
    }
    int rank = 0;
    #ifdef COMPILED_WITH_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    #endif
    if(TS != NULL) delete [] TS;
    TS = new TrajSummary[totNumParticles];

    for(int i = 0; i < totNumParticles; ++i) {
        TS[i].trajSuccess = false;
        TS[i].trajRerun   = false;
        TS[i].trajOmitted = false;
        TS[i].cosChi      = -1;
        TS[i].enRatio     = -1;
        TS[i].timeSteps   = -1;
    }

    if(rank == 0 ) fprintf(stderr,"Beginning trajectory calculation on %d threads\n\n", numThreads);
    double cpuTime = clock();
    double wallTime = omp_get_wtime();

    TrajFileWriter * traj = NULL;
    if(params->GetTrajSetting().test(TO_OUTPUT)) {
        if(traj != NULL) delete traj;
        traj = new TrajFileWriter(params->GetTrajFileName(),numThreads);
    }


    #pragma omp parallel for num_threads(numThreads) schedule(dynamic)
    for(int idx = 0; idx < totNumParticles; ++idx) {
        int i = partInt[idx] / (numVantages*totNumTraj2D);              // enState index
        int j = (partInt[idx] / totNumTraj2D) % numVantages;            // vantage index
        int k = (partInt[idx] / totNumTraj1D) % totNumTraj1D - numTraj; // x-basis index
        int l = (partInt[idx] % totNumTraj1D) - numTraj;                // y-basis index
        double * cP = VP[j].centerPos;
        //Initial velocity (directional) of the gas particle
        double cPLength = sqrt(cP[0]*cP[0]+
                               cP[1]*cP[1]+
                               cP[2]*cP[2]);
        double vInit[3] = {-cP[0]/cPLength * ES[i].speed,
                           -cP[1]/cPLength * ES[i].speed,
                           -cP[2]/cPLength * ES[i].speed};

        double initPos[3] =        //Initial position of the particle
        {cP[0] + VP[j].oBasisX[0]*k*dist + VP[j].oBasisY[0]*l*dist,
         cP[1] + VP[j].oBasisX[1]*k*dist + VP[j].oBasisY[1]*l*dist,
         cP[2] + VP[j].oBasisX[2]*k*dist + VP[j].oBasisY[2]*l*dist};

        Particle * p = NULL;
        if(Parameters::Get()->GetPType() == PT_SPHERICAL) {
            p = new SphericalParticle;
        } else if(Parameters::Get()->GetPType() == PT_DIATOMIC) {
            p = new DiatomicParticle;
        } else {
            //return false;
        }

        p->SetEnRatio(0);
        p->SetPos(initPos);
        p->SetVel(vInit);
        p->SetEnStateIdx(i);
        p->SetInfo(partInfo);

        int threadID = omp_get_thread_num();

        //Perform simulation
        double   dt         = ES[i].timestep;
        double * pos        = p->GetPos();
        double   EnTotInit  = ES[i].EnKinInit + p->FindPotential(pos);
        double   initDistSq = initPos[0]*initPos[0] + initPos[1]*initPos[1] + initPos[2]*initPos[2];
        double * v          = p->GetVel();
        bool     fail       = false;
        int      failCount  = 0;
        double   vfdotvi    = 0;
        double   normvf     = -1;

        do{                    //retry trajectories with smaller timesteps if energy is not conserved
            int maxSteps  = 2* (int) ceil(4*sqrt(initDistSq)/(ES[i].speed*dt));//Particle should move less than 4*initDist
            int steps = 0;    //Time counter
            if(params->GetTrajSetting().test(TO_OUTPUT)) traj->AppendToTraj(pos,threadID);
            do{
                Int->Update(p, dt);
                if (steps%10==0 && params->GetTrajSetting().test(TO_OUTPUT))
                    traj->AppendToTraj(pos,threadID);
                steps++;
            } while (steps < maxSteps && p->GetToCenterSq() < 1.1*initDistSq);
            p->SetSteps(steps);
            TS[idx].timeSteps = steps;
            if(steps == maxSteps) {
                fprintf(stderr, "Maximum steps reached, omitting! initpos: {%.2lf,%.2lf,%.2lf}->{%.2lf,%.2lf,%.2lf}\n", initPos[0], initPos[1], initPos[2], pos[0], pos[1], pos[2]);
                if(rank == 0) outputPercentage("Calculating CCS:");
                TS[idx].trajOmitted = true;
                TS[idx].cosChi = 1;    //Trajectory became trapped, do not include data in calculation
                break;
            }
    
            //Analyze results of trajectory
            normvf     = sqrt(v[0]*v[0]     + v[1]*v[1]     + v[2]*v[2]);       //Final speed
            p->SetEnRatio((0.5*mu*normvf*normvf + p->FindPotential(pos))/EnTotInit);
            TS[idx].enRatio = p->GetEnRatio();
            if(abs(p->GetEnRatio()-1) > 0.01) {
                //fprintf(stderr,"Energy not conserved for initpos: {%lf,%lf,%lf}\n",initPos[0],initPos[1],initPos[2]);
                //outputPercentage("Calculating CCS:");
                TS[idx].trajRerun = true;
                dt /= 2;
                fail = true;
                ++failCount;
                if(failCount > 5) {
                    fprintf(stderr, "Trajectory could not conserve energy at 1/32 timestep. omitting. (%.8lf%%) %lf %lf\n", 100*(p->GetEnRatio()-1), normvf, p->FindPotential(pos));
                    if(rank == 0) outputPercentage("Calculating CCS:");
                    TS[idx].trajOmitted = true;
                    TS[idx].cosChi = 1;
                    break;
                }
                p->SetPos(initPos);
                p->SetVel(vInit);
            } else {
                fail = false;
                vfdotvi    =      v[0]*vInit[0] + v[1]*vInit[1] + v[2]*vInit[2];    //Dot product of initial and final velocities
                TS[idx].cosChi     = vfdotvi/(normvf*ES[i].speed);   //Cosine of the angle between initial and final velocities
            }
        } while (fail == true);
        if(!TS[idx].trajOmitted) TS[idx].trajSuccess = true;

        if(params->GetTrajSetting().test(TO_OUTPUT)) {
            traj->Write(threadID);
            traj->ClearTraj(threadID);
        }
        if(idx % 1000 == 0 && rank == 0) outputPercentage("Calculating CCS:");
        delete p;
    }
    if(params->GetTrajSetting().test(TO_OUTPUT)) {
        if(params->GetTrajSetting().test(TO_COMBINED)) traj->Combine(numThreads);
        delete traj;
    }

    delete Int;

    Summarize();

    return crossSection;
}

void System::Reduce_MPI() {
    #ifdef COMPILED_WITH_MPI
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    int tempInt;
    double tempDouble;
    MPI_Barrier(MPI_COMM_WORLD);
    for(int i = 0; i < Parameters::Get()->GetEnStates(); ++i) {
        MPI_Allreduce(&s->enStateSkipped[i], &tempInt,    1, MPI_INT,    MPI_SUM, MPI_COMM_WORLD);
        s->enStateSkipped[i] = tempInt;
        MPI_Allreduce(&s->enStateSuccess[i], &tempInt,    1, MPI_INT,    MPI_SUM, MPI_COMM_WORLD);
        s->enStateSuccess[i] = tempInt;
        MPI_Allreduce(&s->enStateOmitted[i], &tempInt,    1, MPI_INT,    MPI_SUM, MPI_COMM_WORLD);
        s->enStateOmitted[i] = tempInt;
        MPI_Allreduce(&s->enStateRerun[i],   &tempInt,    1, MPI_INT,    MPI_SUM, MPI_COMM_WORLD);
        s->enStateRerun[i] = tempInt;
        MPI_Allreduce(&s->enRatioMax[i],     &tempDouble, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
        s->enRatioMax[i] = tempDouble;
        MPI_Allreduce(&s->enRatioMin[i],     &tempDouble, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
        s->enRatioMin[i] = tempDouble;
        MPI_Allreduce(&s->stepsMax[i],       &tempInt,    1, MPI_INT,    MPI_MAX, MPI_COMM_WORLD);
        s->stepsMax[i] = tempInt;
        MPI_Allreduce(&s->stepsMin[i],       &tempInt,    1, MPI_INT,    MPI_MIN, MPI_COMM_WORLD);
        s->stepsMin[i] = tempInt;
        MPI_Allreduce(&s->stepsAvg[i],       &tempDouble, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
        s->stepsAvg[i] = tempDouble;
        MPI_Allreduce(&s->enRatioSumSq[i],   &tempDouble, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
        s->enRatioSumSq[i] = tempDouble;
    }
    MPI_Allreduce(&totSuccess,   &tempInt,    1, MPI_INT,    MPI_SUM, MPI_COMM_WORLD);
    totSuccess = tempInt;
    MPI_Allreduce(&totOmitted,   &tempInt,    1, MPI_INT,    MPI_SUM, MPI_COMM_WORLD);
    totOmitted = tempInt;
    MPI_Allreduce(&totSkipped,   &tempInt,    1, MPI_INT,    MPI_SUM, MPI_COMM_WORLD);
    totSkipped = tempInt;
    MPI_Allreduce(&totRerun,     &tempInt,    1, MPI_INT,    MPI_SUM, MPI_COMM_WORLD);
    totRerun = tempInt;
    // Although the CCS is a weighted average, all we need to do is add the pre-weighted peices
    MPI_Allreduce(&crossSection, &tempDouble, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    crossSection = tempDouble;
    #endif
}

void System::Summarize() {

    totSuccess = 0; //Number of total successful trajectories
    totRerun   = 0; //Number of trajectories rerun due to lack of energy conservation
    totSkipped = 0;
    totOmitted = 0;
    double num = 0; // num/den=CCS
    double den = 0;
    int    maxSteps = 0;
    int    minSteps = (int) 1e8;
    double avgSteps = 0;


    int enStates = Parameters::Get()->GetEnStates();
    if(s != NULL) DeleteSummary();
    CreateSummary();

    double * weight = new double[enStates];

    double ** enStateAvgCS   = new double*[enStates];
    int    ** enStateSuccess = new int*[enStates];
    int    ** enStateRerun   = new int*[enStates];
    int    ** enStateOmitted = new int*[enStates];
    double ** enRatioAvg     = new double*[enStates];
    double ** enRatioMax     = new double*[enStates];
    double ** enRatioMin     = new double*[enStates];
    double ** enRatioSumSq   = new double*[enStates];
    double ** enRatioStdev   = new double*[enStates];
    int    ** stepsMax       = new int*[enStates];
    int    ** stepsMin       = new int*[enStates];
    double ** stepsAvg       = new double*[enStates];
    for(int i = 0; i < enStates; ++i) {
        weight[i]         = ES[i].GetWeighting(i);
        enStateAvgCS[i]   = new double[numThreads];
        enStateSuccess[i] = new int[numThreads];
        enStateRerun[i]   = new int[numThreads];
        enStateOmitted[i] = new int[numThreads];
        enRatioAvg[i]     = new double[numThreads];
        enRatioMax[i]     = new double[numThreads];
        enRatioMin[i]     = new double[numThreads];
        enRatioSumSq[i]   = new double[numThreads];
        enRatioStdev[i]   = new double[numThreads];
        stepsMax[i]       = new int[numThreads];
        stepsMin[i]       = new int[numThreads];
        stepsAvg[i]       = new double[numThreads];
        for(int j = 0; j < numThreads; ++j) {
            enStateAvgCS[i][j]   = 0;
            enStateSuccess[i][j] = 0;
            enStateOmitted[i][j] = 0;
            enStateRerun[i][j]   = 0;
            enRatioAvg[i][j]     = 0;
            enRatioMax[i][j]     = DBL_MIN;
            enRatioMin[i][j]     = DBL_MAX;
            enRatioSumSq[i][j]   = 0;
            enRatioStdev[i][j]   = 0;
            stepsMax[i][j]       = INT_MIN;
            stepsMin[i][j]       = INT_MAX;
            stepsAvg[i][j]       = 0;
        }
        s->enStateAvgCS[i]    = 0;
        s->enStateSuccess[i]  = 0;
        s->enStateSkipped[i]  = 0;
        s->enStateRerun[i]    = 0;
        s->enStateOmitted[i]  = 0;
        s->enRatioAvg[i]      = 0;
        s->enRatioMax[i]      = DBL_MIN;
        s->enRatioMin[i]      = DBL_MAX;
        s->enRatioStdev[i]    = 0;
        s->enRatioSumSq[i]    = 0;
        s->stepsMax[i]        = INT_MIN;
        s->stepsMin[i]        = INT_MAX;
        s->stepsAvg[i]        = 0;
    }

    #pragma omp parallel for num_threads(numThreads) schedule(dynamic)
    for(int idx = 0; idx < totNumParticles; ++idx) {
        int threadID = omp_get_thread_num();
        int i = partInt[idx] / (numVantages*totNumTraj2D);              // enState index
        if(TS[idx].trajOmitted) {
            ++enStateOmitted[i][threadID];
            continue;
        } else {
            ++enStateSuccess[i][threadID];
            if(TS[idx].trajRerun) {
                ++enStateRerun[i][threadID];
            }
        }
        enStateAvgCS[i][threadID] += (1-TS[idx].cosChi)*dist*dist/numVantages;
        enRatioMax[i][threadID]    = max(enRatioMax[i][threadID],TS[idx].enRatio);
        enRatioMin[i][threadID]    = min(enRatioMin[i][threadID],TS[idx].enRatio);
        stepsMax[i][threadID]      = max(stepsMax[i][threadID],TS[idx].timeSteps);
        stepsMin[i][threadID]      = min(stepsMin[i][threadID],TS[idx].timeSteps);
        enRatioAvg[i][threadID]   += TS[idx].enRatio;
        enRatioSumSq[i][threadID] += TS[idx].enRatio * TS[idx].enRatio;
        stepsAvg[i][threadID]     += TS[idx].timeSteps;
    }

    // combine threaded data
    for(int i = 0; i < enStates; ++i) {
        for(int j = 0; j < numThreads; ++j) {
            s->enStateAvgCS[i]   += enStateAvgCS[i][j];
            s->enStateSuccess[i] += enStateSuccess[i][j];
            s->enStateRerun[i]   += enStateRerun[i][j];
            s->enStateOmitted[i] += enStateOmitted[i][j];
            s->enRatioAvg[i]     += enRatioAvg[i][j];
            s->enRatioSumSq[i]   += enRatioSumSq[i][j];
            s->enRatioMax[i]      = max(s->enRatioMax[i],enRatioMax[i][j]);
            s->enRatioMin[i]      = min(s->enRatioMin[i],enRatioMin[i][j]);
            s->stepsMax[i]        = max(s->stepsMax[i],stepsMax[i][j]);
            s->stepsMin[i]        = min(s->stepsMin[i],stepsMin[i][j]);
            s->stepsAvg[i]       += stepsAvg[i][j];
        }
        //numerator and denominator for weighted average
        num    += weight[i] * s->enStateAvgCS[i];
        den    += weight[i];
    }
    delete[] weight;

    for(int i = 0; i < enStates; ++i) {
        if(enStateAvgCS[i]   != NULL) delete [] enStateAvgCS[i];
        if(enStateSuccess[i] != NULL) delete [] enStateSuccess[i];
        if(enStateRerun[i]   != NULL) delete [] enStateRerun[i];
        if(enStateOmitted[i] != NULL) delete [] enStateOmitted[i];
        if(enRatioAvg[i]     != NULL) delete [] enRatioAvg[i];
        if(enRatioMax[i]     != NULL) delete [] enRatioMax[i];
        if(enRatioMin[i]     != NULL) delete [] enRatioMin[i];
        if(enRatioSumSq[i]   != NULL) delete [] enRatioSumSq[i];
        if(enRatioStdev[i]   != NULL) delete [] enRatioStdev[i];
        if(stepsMax[i]       != NULL) delete [] stepsMax[i];
        if(stepsMin[i]       != NULL) delete [] stepsMin[i];
        if(stepsAvg[i]       != NULL) delete [] stepsAvg[i];
    }
    if(enStateAvgCS   != NULL) delete [] enStateAvgCS;
    if(enStateSuccess != NULL) delete [] enStateSuccess;
    if(enStateRerun   != NULL) delete [] enStateRerun;
    if(enStateOmitted != NULL) delete [] enStateOmitted;
    if(enRatioAvg     != NULL) delete [] enRatioAvg;
    if(enRatioMax     != NULL) delete [] enRatioMax;
    if(enRatioMin     != NULL) delete [] enRatioMin;
    if(enRatioSumSq   != NULL) delete [] enRatioSumSq;
    if(enRatioStdev   != NULL) delete [] enRatioStdev;
    if(stepsMax       != NULL) delete [] stepsMax;
    if(stepsMin       != NULL) delete [] stepsMin;
    if(stepsAvg       != NULL) delete [] stepsAvg;
    crossSection = num/den;

    Reduce_MPI();
    for(int i = 0; i < enStates; ++i) {
        s->enRatioAvg[i]    /= s->enStateSuccess[i];
        s->enRatioStdev[i]   = sqrt(abs(s->enRatioSumSq[i]/s->enStateSuccess[i] - s->enRatioAvg[i]*s->enRatioAvg[i]));
        s->stepsAvg[i]      /= s->enStateSuccess[i];
        s->enStateSkipped[i] = totTrajectories - s->enStateSuccess[i] - s->enStateOmitted[i];
        totSuccess += s->enStateSuccess[i];
        totOmitted += s->enStateOmitted[i];
        totRerun   += s->enStateRerun[i];
        totSkipped += s->enStateSkipped[i];
    }
}

//Create all particles with initial velocity and position, and set the skipped
//bool if the particle should not be simulated
bool System::SeedParticles() {
    int numAtoms = m->GetNumAtoms();
    int enStates = Parameters::Get()->GetEnStates();

    //for openMP reduction
    int numParticles = 0;
    bool failedSeeding = false;
    int rank = 0;
    int size = 1;
    #ifdef COMPILED_WITH_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    #endif
    // Begin by looking for trajectories to run, and count them up, adding the indices to a list
    // This list will NOT be full. Just the first part will be, based on how many particles
    // should be simulated. This is the current memory-usage bottleneck.
    int * sparseTrajIndices  = new int[totTrajectories/size];
    if(rank == 0) cerr << "A total of " << totTrajectories/size*sizeof(int) << " bytes will be required to seed the particles" << endl;
    #pragma omp parallel for num_threads(numThreads) schedule(dynamic)
    for(int idx = rank*totTrajectories/size; idx < (rank+1)*totTrajectories/size; ++idx) {
        if(!failedSeeding) {
            int i = idx / (numVantages*totNumTraj2D);              // enState index
            int j = (idx / totNumTraj2D) % numVantages;            // vantage index
            int k = (idx / totNumTraj1D) % totNumTraj1D - numTraj; // x-basis index
            int l = (idx % totNumTraj1D) - numTraj;                // y-basis index
            double * cP = VP[j].centerPos;
            //Initial velocity (directional) of the gas particle
            double cPLength = sqrt(cP[0]*cP[0]+
                                   cP[1]*cP[1]+
                                   cP[2]*cP[2]);
            double vInit[3] = {-cP[0]/cPLength * ES[i].speed,
                               -cP[1]/cPLength * ES[i].speed,
                               -cP[2]/cPLength * ES[i].speed};

            int threadID = omp_get_thread_num();
            double initPos[3] =        //Initial position of the particle
            {cP[0] + VP[j].oBasisX[0]*k*dist + VP[j].oBasisY[0]*l*dist,
             cP[1] + VP[j].oBasisX[1]*k*dist + VP[j].oBasisY[1]*l*dist,
             cP[2] + VP[j].oBasisX[2]*k*dist + VP[j].oBasisY[2]*l*dist};

            Particle * testPart = NULL;
            if(Parameters::Get()->GetPType() == PT_SPHERICAL) {
                testPart = new SphericalParticle;
            } else if(Parameters::Get()->GetPType() == PT_DIATOMIC) {
                testPart = new DiatomicParticle;
            } else {
                fprintf(stderr, "Unknown Particle type when trying to seed.\n");
                failedSeeding = true;
                #pragma omp flush (failedSeeding)
            }

            testPart->SetPos(initPos);
            testPart->SetVel(vInit);
            testPart->SetEnStateIdx(i);
            testPart->SetInfo(partInfo);
            if(WillNotSkip(testPart)) {
                // Add the index to the list in a thread-safe way
                #pragma omp critical(addParticle)
                {
                    sparseTrajIndices[numParticles] = idx;
                    ++numParticles;
                }
            }
            delete testPart;
            if(numParticles % 100 == 0 && rank == 0 && threadID == 0) fprintf(stderr, "Counting the number of particles to simulate: %lf%%\r", (double) 100*idx*size/totTrajectories);
        }
    }
    if(failedSeeding) return false;
    if(rank == 0) fprintf(stderr, "Counting the number of particles to simulate: 100%%                   \n\n");

    // Condense the sparse list into a full list
    int * trajIndices = new int[numParticles];
    for(int i = 0; i < numParticles; ++i) {
        trajIndices[i] = sparseTrajIndices[i];
    }
    delete [] sparseTrajIndices;

    #ifdef COMPILED_WITH_MPI
    // Count up the number of trajectories each processor found
    int * partPerProc = new int[size];
    MPI_Allgather(&numParticles, 1, MPI_INT, partPerProc, 1, MPI_INT, MPI_COMM_WORLD);

    totNumParticles = 0;
    for(int i = 0; i < size; ++i) totNumParticles += partPerProc[i];

    // Figure out the structure of the combined list, then gather it
    int * gatherPrefixSum = new int[size];
    gatherPrefixSum[0]=0;
    for(int i = 1; i < size; ++i) gatherPrefixSum[i] = gatherPrefixSum[i-1] + partPerProc[i-1];

    int * partIdx = new int[totNumParticles];
    MPI_Allgatherv(trajIndices, numParticles, MPI_INT, partIdx, partPerProc, gatherPrefixSum, MPI_INT, MPI_COMM_WORLD);

    // Determine how many elements each node will have
    int extraElems = totNumParticles % size;
    int * sendNums = new int[size];
   for(int i = 0; i < size; ++i ) {
        if(i < extraElems) sendNums[i] = totNumParticles/size + 1;
        else sendNums[i] = totNumParticles/size;
    }

    // Prepare for scattering the indices to all nodes, IN EQUAL PROPORTIONS
    int * scatterPrefixSum = new int[size];
    scatterPrefixSum[0] = 0;
    for(int i = 1; i < size; ++i) scatterPrefixSum[i] = scatterPrefixSum[i-1] + sendNums[i-1];

    int numElemsNode = sendNums[rank];
    int * partIdxProc = new int[numElemsNode];
    MPI_Scatterv(partIdx, sendNums, scatterPrefixSum, MPI_INT, partIdxProc, numElemsNode, MPI_INT, 0, MPI_COMM_WORLD);
    // We want totNumParticles to be our loop test variable, so it has to be processor-dependent
    totNumParticles = numElemsNode;
    delete [] partPerProc;
    delete [] gatherPrefixSum;
    delete [] partIdx;
    delete [] sendNums;
    delete [] scatterPrefixSum;
    delete [] trajIndices;
    #else
    totNumParticles = numParticles;
    int * partIdxProc = trajIndices;
    #endif


    partInt = new int[totNumParticles];
    //totMemory += totNumParticles*sizeof(int);

    #pragma omp parallel for num_threads(numThreads)
    for(int index = 0; index < totNumParticles; ++ index) {
        partInt[index] = partIdxProc[index];
    }
    if(rank == 0) fprintf(stderr, "Seeding Particles: 100%%                          \n\n");
    delete [] partIdxProc;
    //fprintf(stderr, "In seeding %d particles, %d bytes were stored\n", totNumParticles, totMemory);
    return true;
}

bool System::WillNotSkip(Particle * testPart) {
    int i = testPart->GetEnStateIdx();
    double * initPos = testPart->GetPos();
    double * vInit   = testPart->GetVel();
    double * atomPos = m->GetAtomPos();
    int numAtoms = m->GetNumAtoms();
 
    //Find approx. position of particle's closest approach to molecule
    double dSqMin = DBL_MAX;   //Large inital value
    double posClose[3] = {0,0,0};
    for(int atom = 0; atom < numAtoms; ++atom){
        double distance[3] = {initPos[0] - atomPos[3*atom+0],
                              initPos[1] - atomPos[3*atom+1],
                              initPos[2] - atomPos[3*atom+2]};
        //Time to closest approach (linear) = -V.R/||V||^2
        double time        = -(vInit[0]*distance[0] + vInit[1]*distance[1] + vInit[2]*distance[2])/ES[i].speed/ES[i].speed;
        double rClose[3]   = {distance[0] + vInit[0]*time,
                              distance[1] + vInit[1]*time,
                              distance[2] + vInit[2]*time};
        double dSq         = rClose[0]*rClose[0] + rClose[1]*rClose[1] + rClose[2]*rClose[2];
        if(dSq<dSqMin) {
            posClose[0] = rClose[0] + atomPos[3*atom+0];
            posClose[1] = rClose[1] + atomPos[3*atom+1];
            posClose[2] = rClose[2] + atomPos[3*atom+2];
            dSqMin      = dSq;
        }
    }
    //Skip if closest U is small compared to T, and is not in the C6-C12 transition region
    if(abs(testPart->FindPotential(posClose)/ES[i].EnKinInit) < 0.004 && dSqMin > 36) {
        return false;
    }
    return true;
}

void System::UpdateParticle(Particle * p, double dt, double * force) {

    double * v   = p->GetVel();
    double * pos = p->GetPos();

    v[0]   += dt/mu * force[0];
    v[1]   += dt/mu * force[1];
    v[2]   += dt/mu * force[2];

    pos[0] += dt*v[0];
    pos[1] += dt*v[1];
    pos[2] += dt*v[2];

    p->SetToCenterSq(pos[0]*pos[0] + pos[1]*pos[1] + pos[2]*pos[2]);
}

//Rotate about the z-axis by theta, then rotate about the x-axis by phi
void System::RotateMolecule(double theta, double phi) {
    double * atomPos = m->GetAtomPos();
    for(int atom = 0; atom < m->GetNumAtoms(); ++atom) {
        double x_orig = atomPos[3*atom+0];
        double y_orig = atomPos[3*atom+1];
        double z_orig = atomPos[3*atom+2];

        atomPos[3*atom+0] = x_orig*cos(theta) - y_orig*cos(phi)*sin(theta) + z_orig*sin(phi)*sin(theta);
        atomPos[3*atom+1] = x_orig*sin(theta) + y_orig*cos(phi)*cos(theta) - z_orig*sin(phi)*cos(theta);
        atomPos[3*atom+2] =                     y_orig*sin(phi)            + z_orig*cos(phi);
    }
}

/************* EnergyState.cpp ******************/
#include "EnergyState.h"
#include "System.h"
#include "Parameters.h"
#include <cmath>        // sqrt, exp
#include <iostream>     // cerr, endl;

using namespace std;

void EnergyState::SetEnParams(double speed) {
    this -> speed = speed;
    EnKinInit     = 0.5*System::Get()->mu*speed*speed;

    if(speed<500)       timestep = 0.125/speed;  //loosely based on timestep used in MOBCAL
    else if(speed<1500) timestep = 0.0875/speed+7.5/100000;
    else                timestep = 0.2/speed;
}

EnergyState::~EnergyState() {
//    cerr << "deleting an energy state" << endl;
}

void EnergyState::Print() {
    cerr << "EnKinInit = " << EnKinInit << endl;
    cerr << "Speed     = " << speed << endl;
    cerr << "timestep  = " << timestep << endl;
}

double EnergyState::GetWeighting(int i) {
    System * sys = System::Get();
    double lowSpeed;                       //Low energy bound for energy state integral
    double prevSpeed;
    prevSpeed = (i == 0) ? 0 : speed-sys->deltaVel*sqrt(2*sys->RT/sys->mu);
    lowSpeed  = (i == 0) ? 0 : (prevSpeed+speed)/2;

    double lowSpdSq     = lowSpeed * lowSpeed;
    double lowSpdFourth = lowSpdSq * lowSpdSq;
    double highSpeed;                      //High energy bound for energy state integral

    bool   goToInf = (i == Parameters::Get()->GetEnStates()-1);
    if(!goToInf) {
        double nextSpeed = speed+sys->deltaVel*sqrt(2*sys->RT/sys->mu);
        highSpeed = (speed+nextSpeed)/2;
        double highSpdSq     = highSpeed * highSpeed;
        double highSpdFourth = highSpdSq * highSpdSq;
        return exp(-sys->mu*lowSpdSq/(2*sys->RT)) *
            (lowSpdFourth*sys->mu*sys->mu + 4*lowSpdSq*sys->RT*sys->mu + 8*sys->RT*sys->RT) -
               exp(-sys->mu*highSpdSq/(2*sys->RT)) *
            (highSpdFourth*sys->mu*sys->mu + 4*highSpdSq*sys->RT*sys->mu + 8*sys->RT*sys->RT);
    }

    //proportional to the analytic integral of v^5*exp(-m*v^2/(2RT))
    return  exp(-sys->mu*lowSpdSq/(2*sys->RT)) * 
                       (lowSpdFourth*sys->mu*sys->mu +
                          4*lowSpdSq*sys->RT*sys->mu +
                                   8*sys->RT*sys->RT);
}

#include "Parameters.h"

using namespace std;

int main() {
    Parameters * params = Parameters::Get();
    if(params == NULL) return -1;
    return 1;
}

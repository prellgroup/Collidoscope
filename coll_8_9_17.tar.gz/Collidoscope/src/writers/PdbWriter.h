/***************** PdbWriter.h ********************/
#ifndef PDB_WRITER_H
#define PDB_WRITER_H

#include "Writer.h"
//#include "CoordinateFileData.h"
#include "Molecule.h"

using namespace std;

class PdbWriter : public Writer {
  private:
    //CoordinateFileData * cFO;
    Molecule   * m;
  public:
                 PdbWriter(string);
    virtual void Write();
    void         SetAtomInfo(Molecule*);
    //void         SetAtomInfo(CoordinateFileData*);
    
};

#endif

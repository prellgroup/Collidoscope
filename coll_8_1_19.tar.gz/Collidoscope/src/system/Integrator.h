/**************** Integrator.h *************/
#ifndef INTEGRATOR_H
#define INTEGRATOR_H

#include "Particle.h"

using namespace std;

class Integrator {
  private:
  public:
    virtual void Update(Particle*,double) = 0;
};

#endif

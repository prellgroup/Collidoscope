#include "System.h"
#include "Parameters.h"
#include "ChargePlacer.h"

#include "AffinityFileReader.h"
#include "SettingsFileReader.h"
#include "CoordinateFileReader.h"
#include "GeometryFileReader.h"
#include "GasFileReader.h"
#include "SphericalParticleReader.h"
#include "DiatomicParticleReader.h"

#include "InfoFileWriter.h"

#include <omp.h>       // omp_get_wtime()
#include <cstdlib>     // atof, atoi 
#include <cmath>       // fabs
#include <ctime>       // clock

#ifdef COMPILED_WITH_MPI
#include "mpi.h"       // mpi commands
#endif

/******************************************************************************
 *                                                                            *
 *          Collidoscope - A Program to calculate the rotationally            *
 *             averaged cross section of proteins and peptides.               *
 *                                                                            *
 *             Copyright 2017 James S. Prell, Simon A. Ewing, and the         *
 *                            University of Oregon                            *
 *                                                                            *
 *   Created by Simon Ewing at the Prell Lab, University of Oregon.           *
 *                                                                            *
 *   This model uses a 12-6 Lennard-Jones potential, plus point charges       *
 *   modelled at the center of mass (rather than on individual atoms).  In    *
 *   addition, we have chosen to use a fixed vantage point system instead of  *
 *   Monte Carlo integrations.  The vantage points are determined from the    *
 *   vertices on polyhedra, by default a rhombic triacontahedron              *
 *   (32 vertices). Other geometries can be used by changing the file         *
 *   containing the vertices of the polyhedron, named "Geometry.txt"          *
 *                                                                            *
 *   Many of the parameters (such as LJ well depth and radius) were adapted   *
 *   from values used in MOBCAL, a program to calculate mobilities:           *
 *                                                                            *
 *   M. F. Mesleh, J. M. Hunter, A. A. Shvartsburg, G. C. Schatz,             *
 *   and M. F. Jarrold, Structural Information from Ion Mobility              *
 *   Measurements: Effects of the Long Range Potential, J. Phys. Chem. 1996,  *
 *   100, 16082-16086; Erratum, J. Phys. Chem. A 1997, 101, 968.              *
 *                                                                            *
 *  We balanced efficacy and accuracy by making the following design choices: *
 *                                                                            *
 *    - Spacing between trajectories scales with the number of atoms, so that *
 *      the number of trajectories increases roughly linearly with the number *
 *      of atoms, instead of increasing as the square of the number of atoms  *
 *                                                                            *
 *    - The time step scales with velocity, so that the gas particle's        *
 *      initial velocity is small enough that it does not move more           *
 *      than 0.2 angstroms in one time step.                                  *
 *                                                                            *
 *   Description of code:                                                     *
 *                                                                            *
 *    - Read parameters from Settings Input File or the command line and      *
 *      store them into variables                                             *
 *    - Check parameters for consistency and reasonable values.  This         *
 *      section contains the paths the program uses to exit.                  *
 *    - Read in vantage points from Geometry.txt, then create the             *
 *      orthonormal bases for each rotation.                                  *
 *    - Create the system, and fill with energy states, vantage points, and   *
 *      the molecule/ion, and derive information from it.                     *
 *    - Output parameters and other info to command line and                  *
 *      information file.                                                     *
 *    - Begin the cross section calculation:                                  *
 *       - Integrate over energy state and vantage point                      *
 *       - Integrate over impact parameter (2 dimensions)                     *
 *       - Integrate through time (run trajectory)                            *
 *    - Summarize results                                                     *
 *                                                                            *
 *    CHANGELOG:                                                              *
 *                                                                            *
 *        1.1 - Sneaky - 4/6/17:                                              *
 *        - Added MPI functionality.                                          *
 *        - Fixed the polarizability bug, where the polarizability of ALL     *
 *            buffer gas particles had the polarizability of He. It now       *
 *            functions as you would expect.                                  *
 *        - Made the charge placement algorithm not set charge to 0 before    *
 *            running, unless it is guaranteed to work. Previously, partial   *
 *            charge information on small molecules was lost when using "all" *
 *            algorithms                                                      *
 *        - Changed the way that trajectories are stored in memory, in order  *
 *            to decrease memory usage, increase efficiency, and increase     *
 *            parallelizability                                               *
 *        - Included a license in the "Collidoscope/" folder, as well as in   *
 *            "src/main.cpp"                                                  *
 *                                                                            *
 *        1.2 - Windex - 5/2/17:                                              *
 *        - Added more tests to make sure that parameters are valid           *
 *        - Optimized the charge placement algorithm to scale with the charge *
 *            instead of the number of charge sites                           *
 *        - Now the charge placement algorithm is allowed to simulate up to   *
 *            30 million steps, since it is much faster                       *
 *        - The minimum number of steps for the charge placement algorithm has*
 *            been increased from 200,000 to 800,000                          *
 *        - Charge placement algorithm now also displays when it makes a      *
 *            change that decreases the total affinity                        *
 *        - The pdb output for the charge placement algorithm will now almost *
 *            always be written to "filename_charge+.pdb".                    *
 *        - Added the option NOT to use MPI                                   *
 *        - Fixed a bug when using MPI with the charge placement algorithm    *
 *            AND the CCS calculation, where charges were not located         *
 *            correctly on all nodes                                          *
 *        - Added a numerical integration class and corresponding option in   *
 *            the Settings Input File                                         *
 *        - Implemented Runge-Kutta 4th order (RK4) as an integration option  *
 *        - Added the ability to read multiple models in a pdb file, so that  *
 *            complexes can be read properly                                  *
 *        - Now allow for comments in Coordinate Input files (blank lines or  *
 *            lines starting with "#")                                        *
 *        - Can now read MOBCAL ".mfj" files as Coordinate Input Files        *
 *        - Added Windows compatibility                                       *
 *        - Added a changelog!                                                *
 *                                                                            *
 *        5/31/17 Hotfix:                                                     *
 *        - Fixed bug where charges were not being reset before charge        *
 *            placement algorithm                                             *
 *                                                                            *
 *        1.3 - Trucker - 6/12/17:                                            *
 *        - Changed data structure to make more variables protected           *
 *        - Made the charge placement algorithm more robust by adding checks  *
 *            when reading files                                              *
 *        - General improvements on the quality of coding                     *
 *        - Reorganized the makefile to automatically accept new code files   *
 *            when they are created                                           *
 *        - Changed the "coordinateFiles" folder to "CoordinateFiles", to     *
 *            match the casing of the other folders                           *
 *        - Added a check for Coordinate Input Files to ensure that the       *
 *            element is listed                                               *
 *        - Created new classes to allow for easier implementation of new     *
 *            physics                                                         *
 *        - Fixed potential calculation to correctly account for charges at   *
 *            the center of mass                                              *
 *                                                                            *
 ******************************************************************************/

using namespace std;

void PrintParameters() {
    Parameters * params = Parameters::Get();
    System     * sys    = System::Get();
    Molecule   * mol    = sys->GetMolecule();
    double     * molCOM = mol->GetCOM();

    cerr << "Parameters used:" << endl;
    cerr << "#\tSettings Input File      : " << params->GetSettingsFileName() << endl;
    cerr << "\tAlgorithm                : " << params->GetModeString() << endl;
    cerr << "\tInformation Output File  : " << params->GetInfoFileName() << endl;
    cerr << "\tCoordinate Input File    : " << params->GetCoordFileName() << endl;
    cerr << "#\tNumber of atoms          = " << mol->GetNumAtoms() << endl;
    cerr << "\tNet Charge               = " << params->GetCharge() << endl;
    cerr << "\tTemperature              = " << params->GetTemp() << endl;

    if(params->GetMode().test(ALG_CHARGE_PLACER)) {
        cerr << "\tEpsilon                  = " << params->GetEpsilon() << endl;
        cerr << "\tEnergy Output File       : " << params->GetEnergyFileName() << endl;
        cerr << "\tAffinity Input File      : " << params->GetAffinityFileName() << endl;
    }

    if(params->GetMode().test(ALG_CROSS_SECTION)) {
        cerr << "\tParticle Type            : " << params->GetpTypeString() << endl;
        cerr << "\tIntegration Method       : " << params->GetMethodString() << endl;
        cerr << "\tGas Parameter Input File : " << params->GetGasParamFileName() << endl;
        cerr << "\tTrajectory output setting: " << params->GetTrajSettingString() << endl;
        if(Parameters::Get()->GetTrajSetting().test(TO_OUTPUT)) cerr << "\tTrajectory output file  :  " << params->GetTrajFileName() << endl;
        cerr << "\tGeometry Input File      : " << params->GetGeometryFileName() << endl;
        cerr << "#\tVantage Points           = " << System::Get()->numVantages << endl;
        cerr << "\tMinimum Energy           = " << params->GetMinEn() << " RT" << endl;
        cerr << "\tMaximum Energy           = " << params->GetMaxEn() << " RT" << endl;
        cerr << "\tEnergy states            = " << params->GetEnStates() << endl;
        cerr << endl;
        cerr << "\tDerived information:" << endl;
        cerr << "\tRadius of trajectories   = " << System::Get()->bMax << " Angstroms" << endl;
        cerr << "\tMolecular mass           = " << mol->GetMass() << " g/mol" << endl;
        cerr << "\tMu                       = " << System::Get()->mu << " kg/mol" << endl;
        cerr << "\tMoment of Inertia        = " << mol->GetInertia() << " kg*m^2" << endl;
        cerr << "\tCenter of Mass           = {" << molCOM[0] << "," << molCOM[1] << "," << molCOM[2] << "} Angstroms" << endl;
        cerr << "\timpact parameter spacing = " << System::Get()->dist << " Angstroms" << endl << endl;
    }
};

void Initialize(int argc, char ** argv) {
    Parameters   * params  = Parameters::Get();
    System       * sys     = System::Get();

    if(!params->SetFromCommandLine(argc,argv)) exit(-1);
    //Read Settings File and get command line arguments
    SettingsFileReader r(params->GetSettingsFileName());
    if(!r.Read()) exit(-1);

    if(!params->AreValid()) exit(-1);
    if(!params->ChangeFileNames()) exit(-1);

    CoordinateFileReader mReader(params->GetCoordFileName());
    CoordinateFileData * mol    = (CoordinateFileData*) mReader.GetOutput();
    if(!mReader.Read()) exit(-1);

    if(params->GetMode().test(ALG_CHARGE_PLACER) && params->GetCharge() != 0) {
        AffinityFileReader aR(params->GetAffinityFileName());
        if(!aR.Read()) exit(-1);

        ChargePlacer::Get()->SetAffinities((AffinityFileData*) aR.GetOutput());
    }

    sys->AddMolecule(mol);

    if(params->GetMode().test(ALG_CROSS_SECTION)) {
        GasFileReader * gas = NULL;
        if(params->GetPType() == PT_SPHERICAL) gas = new SphericalParticleReader(params->GetGasParamFileName());
        else if(params->GetPType() == PT_DIATOMIC) gas = new DiatomicParticleReader(params->GetGasParamFileName());
        if(!gas->Read()) exit(-1);
        sys->SetMoleculeProperties((GasFileData*) gas->GetOutput());
        delete gas;

        GeometryFileReader geo(params->GetGeometryFileName());
        if(!geo.Read()) exit(-1);
        GeometryFileData   * VP     = (GeometryFileData*) geo.GetOutput();

        sys->CreateVantagePoints(VP);
        sys->SetParams();
        sys->DeriveInformation();
    }
}

int main (int argc, char ** argv) {
    System * sys = System::Get();
    Initialize(argc, argv);
    int rank = 0;
    #ifdef COMPILED_WITH_MPI
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Barrier(MPI_COMM_WORLD);
    #endif

    if(rank == 0) PrintParameters();
 
    //Enter charge placement algorithm if requested
    if(Parameters::Get()->GetMode().test(ALG_CHARGE_PLACER)) {
        if(Parameters::Get()->GetCharge() != 0) {
            if(rank == 0) {
                if(ChargePlacer::Get()->ReplaceCharges(sys->m) == -1) return -1;
            }

            #ifdef COMPILED_WITH_MPI
            // Set all atom charge configurations from root
            for(int i = 0; i < sys->m->GetNumAtoms(); ++i) {
                MPI_Bcast(&sys->m->GetAtoms()[i].charge, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            }
            #endif
             
            sys->m->SetCharges();
        } else {
            if(rank == 0) cerr << "Charge placement requested, but there is 0 net charge. Will not enter charge placement algorithm." << endl;
        }
    }

    double wallTime;
    double cpuTime;

    #ifdef COMPILED_WITH_MPI
    MPI_Barrier(MPI_COMM_WORLD);
    #endif
    double globalCpuTime = 0;
    double globalWallTime = 0;
    if(Parameters::Get()->GetMode().test(ALG_CROSS_SECTION)) {

        if(sys->m->GetCOMCharge() != 0) {
            if(fabs(sys->m->GetCOMCharge())<1e-3) {
                if(rank == 0) {
                    cerr << "Very small difference in charge in Coordinate Input File and net charge." << endl;
                    cerr << "Will have 0 charges at the center of mass." << endl;
                }
                sys->m->GetCOMCharge() = 0;
            }
            else if(rank == 0) cerr << "The molecule will have " << sys->m->GetCOMCharge() << " charges at the center of mass." << endl;
        }

        wallTime = omp_get_wtime();     // Set up a wall timer for the program
        cpuTime = clock();              // Set up a CPU timer for the program

        if(!System::Get()->SeedParticles()) return -1;   //Creates ALL gas particles with initial position and velocity
        double cs = sys->GetCrossSection();

        wallTime = omp_get_wtime() - wallTime;  //stop the timer
        cpuTime = clock() - cpuTime;
        #ifdef COMPILED_WITH_MPI
        MPI_Reduce(&cpuTime, &globalCpuTime, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&wallTime, &globalWallTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        #else
        globalCpuTime = cpuTime;
        globalWallTime = wallTime;
        #endif

        if(rank == 0) {
            cerr << "Avg. cross section for t = " << Parameters::Get()->GetTemp() << " : " << cs << endl << endl;
            cerr << "Program took " << globalWallTime << " seconds\t";
            cerr << "(CPU time: " << globalCpuTime/CLOCKS_PER_SEC << " seconds)" << endl;
        }
    
    }

    if(rank == 0) {
        InfoFileWriter info(Parameters::Get()->GetInfoFileName());
        info.SetTimes(globalWallTime,globalCpuTime/CLOCKS_PER_SEC);
        info.Write();
    }

    delete System::Get();
    delete Parameters::Get();
    delete ChargePlacer::Get();

    #ifdef COMPILED_WITH_MPI
    MPI_Finalize();
    #endif

    return 0;
}

/**************** SphericalParticleData.h *********/
#include "GasFileData.h"

using namespace std;

class SphericalParticleData : public GasFileData {
  private:
  public:
    GasFileData * Copy();
    double pol;
};

/*********** VantagePoint.h ************/
#ifndef VANTAGE_POINT_H
#define VANTAGE_POINT_H

class VantagePoint {
  public:
                 ~VantagePoint();
    double        centerPos[3];
    double        oBasisX[3];
    double        oBasisY[3];
    void          ScaleBasisVectors(double);
    void          SetBasisVectorDirection(double*);
    void          Print();
};

#endif

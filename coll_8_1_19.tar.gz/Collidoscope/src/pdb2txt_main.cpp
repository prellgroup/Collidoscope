#include "CoordinateFileReader.h"
#include <iostream>   // cerr
#include <string>     // string, find, substr
#include <cstdlib>    // exit
#include <cmath>      // log10, abs, ceil
#include <iomanip>    // setw
#include <fstream>    // ofstream
#include <algorithm>  // max

using namespace std;

int digBeforeDec(double num) {
    int a = max(1,(int)ceil(abs(log10(abs(num)))));
    if(num<0) ++a; //has a "-" before decimal
    return a;
}

int main(int argc, char ** argv) {

    if(argc < 2) {
        cerr << "USAGE: ./pdb2txt path_to_pdb_file" << endl;
        exit(-1);
    }

    string inputFileName   = argv[1];
    string outputFileName  = inputFileName.substr(0,inputFileName.find("."));
    outputFileName        += ".txt";
    
    CoordinateFileReader coord(inputFileName);
    coord.Read();
    CoordinateFileData * pdbData = (CoordinateFileData*) coord.GetOutput();

    ofstream txtOutputFile;
    txtOutputFile.open(outputFileName.c_str());
    for(int i = 0; i < pdbData->numAtoms; ++i) {
        txtOutputFile << pdbData->atomList[i].element << "\t";
        txtOutputFile << pdbData->atomList[i].x << "\t";
        txtOutputFile << pdbData->atomList[i].y << "\t";
        txtOutputFile << pdbData->atomList[i].z;
        if(pdbData->atomList[i].charge != 0) txtOutputFile << "\t" << pdbData->atomList[i].charge;
        txtOutputFile << endl;
    }
    txtOutputFile.close();
}

/************* Euler_Int.h **************/
#ifndef EULER_INT_H
#define EULER_INT_H

#include "Integrator.h"

using namespace std;

class Euler_Int : public Integrator {
  private:
  public:
    virtual void Update(Particle*,double);
};

#endif

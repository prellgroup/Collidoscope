/************* VantagePoint.cpp ***********/
#include "VantagePoint.h"
#include <iostream>        // cerr, endl
#include <cmath>           // sqrt

using namespace std;

//Creates a basis using a normalized input vector
void VantagePoint::SetBasisVectorDirection(double * vantage) {
    centerPos[0] = vantage[0];
    centerPos[1] = vantage[1];
    centerPos[2] = vantage[2];
    double norm = sqrt(centerPos[0]*centerPos[0]+centerPos[2]*centerPos[2]);
    if(norm == 0) {   //vantage point lies on y-axis
        oBasisX[0] = 1;
        oBasisX[1] = 0;
        oBasisX[2] = 0;
        oBasisY[0] = 0;
        oBasisY[1] = 0;
        oBasisY[2] = 1;
    } else {
        oBasisX[0] = -centerPos[2]/norm;
        oBasisX[1] = 0;           //Underdetermined system, arbitrarily chose to have the y-component of x-vector = 0.
        oBasisX[2] = centerPos[0]/norm;
        oBasisY[0] = -centerPos[0]*centerPos[1]/norm;
        oBasisY[1] = norm;
        oBasisY[2] = -centerPos[1]*centerPos[2]/norm;
    }
}

void VantagePoint::ScaleBasisVectors(double c) {
    centerPos[0] *= c;
    centerPos[1] *= c;
    centerPos[2] *= c;
}

void VantagePoint::Print() {
    for(int i = 0; i < 3; ++i) {
        cerr << "centerPos[" << i << "] = " << centerPos[i] << endl;
        cerr << "oBasisX[" << i << "]   = " << oBasisX[i] << endl;
        cerr << "oBasisY[" << i << "]   = " << oBasisY[i] << endl; 
    }
}

VantagePoint::~VantagePoint() {
//    cerr << "deleting a vantage point" << endl;
}

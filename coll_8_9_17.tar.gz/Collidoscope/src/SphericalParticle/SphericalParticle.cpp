/***********SphericalParticle.cpp*************/
#include "SphericalParticle.h"
#include "SphericalParticleData.h"
#include "System.h"
#include <cmath>         // pow, sqrt

using namespace std;

SphericalParticle::SphericalParticle() : Particle() {
    mass = 4.002602;           //molar mass in kg/mol
}

double SphericalParticle::FindPotential(double * pos) {
    double * atomPos    = System::Get()->m->GetAtomPos();
    double * atomCharge = System::Get()->m->GetAtomCharge();
    double * energy     = System::Get()->m->GetAtomEnergy();
    double * rMin       = System::Get()->m->GetAtomRmin();
    double   potential  = 0;
    //Electric field vector
    double Ex = 0;
    double Ey = 0;
    double Ez = 0;
    for(int atom = 0; atom < System::Get()->m->GetNumAtoms(); ++atom) {
        double dist[3]    = {pos[0]-atomPos[3*atom+0],
                             pos[1]-atomPos[3*atom+1],
                             pos[2]-atomPos[3*atom+2]};
        double rSq        = dist[0]*dist[0] + dist[1]*dist[1] + dist[2]*dist[2];

        if(rSq > 0.00001) {
            double r6Term     = pow(rMin[atom]*rMin[atom]/rSq, 3);

            if(atomCharge[atom]!=0) {
                double rCub = sqrt(rSq)*rSq;
                // electric field in units of m^-2*10^20
                Ex += dist[0]*atomCharge[atom]/rCub;
                Ey += dist[1]*atomCharge[atom]/rCub;
                Ez += dist[2]*atomCharge[atom]/rCub;
            }

            //LJ 6-12 potential term
            potential += energy[atom] * (r6Term*r6Term - 2*r6Term);
        } else potential += 1e50;    //VERY close to an atom!
    }

    // Add any potential from charges at the center of mass
    if(System::Get()->m->GetCOMCharge() != 0) {
        double rCub = sqrt(toCenterSq)*toCenterSq;
        // electric field in units of m^-2*10^20
        Ex += pos[0]*System::Get()->m->GetCOMCharge()/rCub;
        Ey += pos[1]*System::Get()->m->GetCOMCharge()/rCub;
        Ez += pos[2]*System::Get()->m->GetCOMCharge()/rCub;
    }

    //C4 ion-induced dipole term
    potential -= 0.5 * pol * C4Const * ( Ex*Ex + Ey*Ey + Ez*Ez );
    return potential;
}

void SphericalParticle::FindForce() {

    int numAtoms = System::Get()->m->GetNumAtoms();
    force[0]=0;
    force[1]=0;
    force[2]=0;
    double * atomPos    = System::Get()->m->GetAtomPos();
    double * energy     = System::Get()->m->GetAtomEnergy();
    double * atomCharge = System::Get()->m->GetAtomCharge();
    double * r_min      = System::Get()->m->GetAtomRmin();
    double Ex = 0;
    double Ey = 0;
    double Ez = 0;
    double dExx = 0;
    double dExy = 0;
    double dExz = 0;
    double dEyy = 0;
    double dEyz = 0;
    double dEzz = 0;

    for(int m = 0; m < numAtoms; ++m){       //loop over coordinates of all atoms in scattering center to get acceleration

        double distance[3] = {pos[0]-atomPos[3*m+0],
                              pos[1]-atomPos[3*m+1],
                              pos[2]-atomPos[3*m+2]};

        double rSq = distance[0]*distance[0] + distance[1]*distance[1] + distance[2]*distance[2];
        double rmin6_r8 = pow(r_min[m]/rSq, 4) * r_min[m] * r_min[m];

        //LJ 6-12 force
        double forceConstant = energy[m] * (rmin6_r8*rmin6_r8*rSq - rmin6_r8);
        force[0] += 12 * forceConstant * distance[0];
    	force[1] += 12 * forceConstant * distance[1];
    	force[2] += 12 * forceConstant * distance[2];

        if(atomCharge[m]!=0) {
            double rCub = sqrt(rSq)*rSq;
            //electric Field: units are m^-2*10^20
            Ex += distance[0] * atomCharge[m] / rCub;
            Ey += distance[1] * atomCharge[m] / rCub;
            Ez += distance[2] * atomCharge[m] / rCub;

            //Vector gradient of field in m^-3*10^30
            dExx += atomCharge[m] / rCub - 3*atomCharge[m] * distance[0]*distance[0] / (rCub*rSq);
            dEyy += atomCharge[m] / rCub - 3*atomCharge[m] * distance[1]*distance[1] / (rCub*rSq);
            dEzz += atomCharge[m] / rCub - 3*atomCharge[m] * distance[2]*distance[2] / (rCub*rSq);

            dExy -= 3*atomCharge[m] * distance[0]*distance[1] / (rCub*rSq);
            dEyz -= 3*atomCharge[m] * distance[1]*distance[2] / (rCub*rSq);
            dExz -= 3*atomCharge[m] * distance[0]*distance[2] / (rCub*rSq);
        }
    }

    // add any contribution from charge at the center of mass, if it is present
    if(System::Get()->m->GetCOMCharge() != 0) {
        double rCub = sqrt(toCenterSq)*toCenterSq;
        //electric Field: units are m^-2*10^20
        Ex += pos[0] * System::Get()->m->GetCOMCharge() / rCub;
        Ey += pos[1] * System::Get()->m->GetCOMCharge() / rCub;
        Ez += pos[2] * System::Get()->m->GetCOMCharge() / rCub;

        //Vector gradient of field in m^-3*10^30
        dExx += System::Get()->m->GetCOMCharge() / rCub - 3*System::Get()->m->GetCOMCharge() * pos[0]*pos[0] / (rCub*toCenterSq);
        dEyy += System::Get()->m->GetCOMCharge() / rCub - 3*System::Get()->m->GetCOMCharge() * pos[1]*pos[1] / (rCub*toCenterSq);
        dEzz += System::Get()->m->GetCOMCharge() / rCub - 3*System::Get()->m->GetCOMCharge() * pos[2]*pos[2] / (rCub*toCenterSq);

        dExy -= 3*System::Get()->m->GetCOMCharge() * pos[0]*pos[1] / (rCub*toCenterSq);
        dExz -= 3*System::Get()->m->GetCOMCharge() * pos[0]*pos[2] / (rCub*toCenterSq);
        dEyz -= 3*System::Get()->m->GetCOMCharge() * pos[1]*pos[2] / (rCub*toCenterSq);
    }

    //C4 ion-induced dipole force
    force[0] += pol*C4Const*( Ex*dExx + Ey*dExy + Ez*dExz );
    force[1] += pol*C4Const*( Ex*dExy + Ey*dEyy + Ez*dEyz );
    force[2] += pol*C4Const*( Ex*dExz + Ey*dEyz + Ez*dEzz );
}

void SphericalParticle::SetInfo(GasFileData * gas) {
    SphericalParticleData * info = (SphericalParticleData *) gas;
    this->pol = info->pol;
}

double SphericalParticle::GetPol() {
    return pol;
}

/******** CoordinateFileReader.cpp *********/
#include "CoordinateFileReader.h"    // Command declarations
#include "StringManip.h"             // CleanString
#include <fstream>                   // ifstream
#include <iostream>                  // input/output commands
#include <cstdlib>                   // atoi, atof
#include <cstring>                   // strstr
#include <cstdio>                    // cerr, endl
#include <algorithm>                 // remove_if
#include <cctype>                    // isspace

CoordinateFileReader::CoordinateFileReader(string fileName) : FileReader(fileName) {
    output = new CoordinateFileData;
}

CoordinateFileReader::~CoordinateFileReader() {
    //cerr << "deleting Coordinate File Reader" << endl;
    delete (CoordinateFileData*) output;
    output = NULL;
}

bool CoordinateFileReader::Read() {
    const char * pdb = strstr(fileName.c_str(),".pdb");
    const char * mfj = strstr(fileName.c_str(),".mfj");
    if(pdb != NULL) return ReadPDB();
    if(mfj != NULL) return ReadMFJ();
    else            return ReadTXT();
}

bool CoordinateFileReader::ReadPDB() {
    CoordinateFileData * out = (CoordinateFileData*) output;
    ifstream file;
    file.open(fileName.c_str(), std::ifstream::in);
    if(file.fail()) {
        cerr << "Coordinate Input File \"" << fileName << "\" did not open." << endl;
        return false;
    }

    //Retrieve the number of atoms from the file
    out->numAtoms = 0;
    string line;
    std::getline(file,line);
    while(!file.eof()) {
        if(line.substr(0,4) == "ATOM") ++out->numAtoms;
        std::getline(file,line);
    }

    if(out->numAtoms == 0) {
        cerr << "Found no valid atoms in " << fileName;
        cerr << ". The line containing the coordinates must start with ATOM. Cross section = 0." << endl;
         return false;
    }

    //Reset input file
    file.clear();
    file.seekg(0);

    out->atomList = new AtomInfo[out->numAtoms];

    //Retrieve atom information from file
    int i = 0;
    out->numRes = 0;
    out->numChains = 0;
    char prevChain = 'z';
    int prevResNum = 0;
    out->chainInfo = true;

    int curModel = -1;

    std::getline(file,line);
    //read until the line begins with "ATOM" or "MODEL"
    while(line.substr(0,4) != "ATOM" && !file.eof() && line.substr(0,6) != "MODEL ") std::getline(file,line);

    while(!file.eof()) {
        if(line.substr(0,6) == "MODEL ") {
            int newModel = atoi(line.substr(10,4).c_str());
            if(newModel == curModel) {
                cerr << "Same model number twice in a row (" << curModel << "," << newModel << ") in " << fileName << ": ";
                cerr << line << endl;
                cerr << "Please change formatting." << endl;
                return false;
            }
            curModel = newModel;
            std::getline(file, line);
            while(line.substr(0,4) != "ATOM" && !file.eof() && line.substr(0,6) != "MODEL ") std::getline(file,line);
            continue;
        }

        if(curModel == -1) curModel = 1; // If no model is specified, default to 1

        if(line.length() < 78) {
            cerr << "Misformatted line in " << fileName << ", atom #" << i << endl;
            return false;
        }
        AtomInfo * curAtom = &out->atomList[i];

        //Extract data from line
        curAtom->model    = curModel;
        curAtom->serial   = atoi(line.substr(6,5).c_str());
        curAtom->name     = line.substr(12,4);
        curAtom->resName  = line.substr(17,3);
        curAtom->chainID  = line[21];
        curAtom->resSeq   = atoi(line.substr(22,4).c_str());
        curAtom->x        = atof(line.substr(30,8).c_str());
        curAtom->y        = atof(line.substr(38,8).c_str());
        curAtom->z        = atof(line.substr(46,8).c_str());
        curAtom->element  = line.substr(76,2);
        curAtom->atomType = DetermineAtomType(CleanString(curAtom->element));

        CleanString(curAtom->name);
        CleanString(curAtom->resName);

        // Make sure that there is an element name present
        if( curAtom->element == "") {
            cerr << "Atom #" << curAtom->serial << " has no Element specified in column 77-78" << endl;
            return false;
        }

        //Determine if a charge is present on this atom
        if(line.length() >= 80 && line[78] != ' ') {
            //-'0' converts from a char to an int (stored as a double)
            if       (line[79] == '-') {
                curAtom->charge = -(line[78]-'0');
            } else if(line[79] == '+') {
                curAtom->charge =   line[78]-'0';
            } else {
                cerr << "unknown charge on atom " << i << endl;
                return false;
            }
        } else {
            curAtom->charge = 0;
        }

        //Determine the number of residues
        if(prevResNum != curAtom->resSeq) {
            prevResNum = curAtom->resSeq;
            ++out->numRes;
        }

        //Determine total number of chains (for N-terminal data)
        if(prevChain != curAtom->chainID) {
            prevChain = curAtom->chainID;
            ++out->numChains;
        }

        //Determine if chain information is present
        if(curAtom->resName == "   " || curAtom->chainID == ' ' || curAtom->resSeq == 0) out->chainInfo = false;

        std::getline(file,line);
        while(line.substr(0,4) != "ATOM" && !file.eof() && line.substr(0,6) != "MODEL ") std::getline(file,line);
        ++i;
    }
    return true;
}

bool CoordinateFileReader::ReadMFJ() {
    CoordinateFileData * out = (CoordinateFileData*) output;
    out->chainInfo = false; // MFJ files have no chain information
    ifstream file;
    file.open(fileName.c_str(), std::ifstream::in);
    if(file.fail()) {
        cerr << "Coordinate Input File \"" << fileName << "\" did not open." << endl;
        return false;
    }

    string line;
    std::getline(file, line);  // Ignore the title line
    std::getline(file, line);  // Ignore the 2nd line, use only the first set of coordinates
    file >> out->numAtoms;     // The third line should only contain the number of atoms

    file >> line;              // units to use for the coordinates
    double unitScaling = (line == "au" ? 0.529177 : 1); // Assume angstroms unless specifically specified au

    string chargeOpt;
    file >> chargeOpt;         // specifies what to do with charges, calc used by default
    
    double otherScaling;
    file >> otherScaling;      // should just contain a number for additional scaling

    out->atomList = new AtomInfo[out->numAtoms];
    double totCharge = 0;
    for(int i = 0; i < out->numAtoms; ++i) {
        file >> out->atomList[i].x;
        file >> out->atomList[i].y;
        file >> out->atomList[i].z;
        int mass;
        file >> mass;

        if(file.peek()=='\t' || file.peek()==' ') file >> out->atomList[i].charge;
        else out->atomList[i].charge = 0;

        // scale coordinates by the 2 scaling factors
        out->atomList[i].x *= unitScaling * otherScaling;
        out->atomList[i].y *= unitScaling * otherScaling;
        out->atomList[i].z *= unitScaling * otherScaling;

        // translate mfj data to the types of data we use in Collidoscope
        out->atomList[i].element  = MFJMassToElement(mass);
        out->atomList[i].atomType = DetermineAtomType(out->atomList[i].element);

        if(ToLower(chargeOpt) == "none") out->atomList[i].charge = 0; // ignore charges
        totCharge += out->atomList[i].charge;

        // Following information is not present in the .mfj format
        out->atomList[i].model   = 1;
        out->atomList[i].serial  = i+1;
        out->atomList[i].name    = "    ";
        out->atomList[i].resName = "UNK";
        out->atomList[i].chainID = 'A';
        out->atomList[i].resSeq  = 1;
    }

    if(ToLower(chargeOpt) == "equal") {
        for(int i = 0; i < out->numAtoms; ++i) {
            out->atomList[i].charge = totCharge/out->numAtoms;
        }
    }
    return true;
}

string CoordinateFileReader::MFJMassToElement(int mass) {
  switch(mass) {
    case 1:  return "H";
    case 12: return "C";
    case 14: return "N";
    case 16: return "O";
    case 23: return "Na";
    case 31: return "P";  // Not in original MOBCAL, but it is in a version that computes CCS N2 (by Matt Bush)
    case 32: return "S";
    default: return "UNK";
  }
}

bool CoordinateFileReader::ReadTXT() {
    CoordinateFileData * out = (CoordinateFileData*) output;
    out->chainInfo = false; // TXT files have no chain information
    ifstream file;
    file.open(fileName.c_str(), std::ifstream::in);
    if(file.fail()) {
        cerr << "Coordinate Input File \"" << fileName << "\" did not open." << endl;
        return false;
    }
    //Determine the number of atoms in the file first
    out->numAtoms = 0;
    string line;
    std::getline(file, line);
    while(!file.eof()) {
        cerr << "|" << line << "|" << endl;
        if(line[0] == '#' || line == "" || line == "\r") {
            std::getline(file, line);
            continue;
        }
        ++out->numAtoms;
        std::getline(file,line);
    }

    if(out->numAtoms == 0) {
        cerr << fileName << " is an empty file, so no atoms are present. Cross section = 0." << endl;
        return false;
    }

    out->atomList = new AtomInfo[out->numAtoms];

    //Reset input file
    file.clear();
    file.seekg(0);

    //Retrieve atom information from file
    for(int i = 0; i < out->numAtoms; ++i) {
        if(file.peek() == '#' || file.peek() == '\n' || file.peek() == '\r') {
            file.ignore(1024, '\n');
            --i; // this line is not an atom...
            continue;
        }
        file >> out->atomList[i].element;
        file >> out->atomList[i].x;
        file >> out->atomList[i].y;
        file >> out->atomList[i].z;
        //charge CAN be non-integer in this format!
        if(file.peek()=='\t' || file.peek()==' ') file >> out->atomList[i].charge;
        else out->atomList[i].charge = 0;
        out->atomList[i].atomType = DetermineAtomType(out->atomList[i].element);

        //Following information is not present in the .txt format
        out->atomList[i].model   = 1;
        out->atomList[i].serial  = i+1;
        out->atomList[i].name    = "    ";
        out->atomList[i].resName = "UNK";
        out->atomList[i].chainID = 'A';
        out->atomList[i].resSeq  = 1;
    }
    return true;
}

AtomType CoordinateFileReader::DetermineAtomType(string type) {
    if     (ToLower(type) == "c")  return AT_C;
    else if(ToLower(type) == "h")  return AT_H;
    else if(ToLower(type) == "n")  return AT_N;
    else if(ToLower(type) == "o")  return AT_O;
    else if(ToLower(type) == "s")  return AT_S;
    else if(ToLower(type) == "na") return AT_Na;
    else if(ToLower(type) == "cl") return AT_Cl;
    else if(ToLower(type) == "p")  return AT_P;
    else                           return AT_UNKNOWN;
}

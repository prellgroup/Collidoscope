/*************** CoordinateFileData.h ***********/
#ifndef COORDINATE_FILE_DATA_H
#define COORDINATE_FILE_DATA_H

#include "FileData.h"
#include <string>

using namespace std;

enum AtomType {
    AT_C,
    AT_P,
    AT_H,
    AT_N,
    AT_O,
    AT_S,
    AT_Na,
    AT_Cl,
    AT_UNKNOWN
};

struct AtomInfo {
    int      model;
    AtomType atomType;
    int      serial;
    string   name;
    string   resName;
    char     chainID;
    int      resSeq;
    double   x;
    double   y;
    double   z;
    string   element;
    double   charge;
};

class CoordinateFileData : public FileData {
  public:
    AtomInfo            * atomList;
    int                   numAtoms;
    int                   numRes;
    int                   numChains;
    bool                  chainInfo;
    int                   firstRes;
                          CoordinateFileData();
                         ~CoordinateFileData();
    bool                  ChainInfoPresent();
};

#endif

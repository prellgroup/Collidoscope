/********** GeometryFileReader.h ************/
#ifndef GEOMETRY_FILE_READER_H
#define GEOMETRY_FILE_READER_H

#include "FileReader.h"

using namespace std;

class GeometryFileReader : public FileReader {
  public:
                 GeometryFileReader(std::string);
                ~GeometryFileReader();
    virtual bool Read();
};

#endif

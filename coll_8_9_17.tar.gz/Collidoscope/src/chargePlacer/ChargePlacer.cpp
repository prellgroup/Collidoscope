/************** ChargePlacer.cpp ****************/
#include "ChargePlacer.h"              //command declarations
#include "LinkedList.h"
#include "PdbWriter.h"
#include "Parameters.h"
#include <fstream>                    //ofstream data type
#include <cmath>                      //exp, sqrt
#include <iostream>                   //input/output commands
#include <ctime>                      //time to seed srand
#include <cstdlib>                    //rand, srand
#include <sstream>                    //ostringstream
#include <omp.h>

//Ke^2*Na*10^10, the constant used in molar coulomb potentials, after accounting
//for the angstrom units of distance
double ChargePlacer::enConst = 1383925.76;
ChargePlacer * ChargePlacer::instance = NULL;
double ChargePlacer::RT      = 2478.8191;

void ChargePlacer::SetAffinities(AffinityFileData * affinities) {
    this -> affinities = affinities->data;
}

ChargePlacer::~ChargePlacer() {
//cerr << "deleting the Charge Placement algorithm." << endl;
}

ChargePlacer * ChargePlacer::Get() {
    if(ChargePlacer::instance == NULL) ChargePlacer::instance = new ChargePlacer;
    return ChargePlacer::instance;
}

void ChargePlacer::Place(AtomInfo ** sitesList, int * affinity) {
    string energyFileName = Parameters::Get()->GetEnergyFileName();
    int charge = (int) Parameters::Get()->GetCharge();
    cerr << fixed;

    //Seed random number generator
    srand( (unsigned int) time(NULL));

    //Initialize all charge sites to have no charges
    for(int i = 0; i < numSites; ++i) sitesList[i]->charge = 0;

    //Randomly generate 1000 charge configurations
    int * trialConfigs[1000];
    for(int i = 0; i < 1000; ++i) {
		trialConfigs[i] = new int[charge];
        //Randomly seed charges and make a list of currently charged sites
        for(int j = 0; j < charge;++j) trialConfigs[i][j]=-1;
        for(int j = 0; j < charge;++j) {
            int toCharge = rand() % numSites;
    
            for(int k = 0; k < charge; ++k) {
                if(toCharge == trialConfigs[i][k]) {
                    --j;
                    break;
                }
                if(k == charge-1) trialConfigs[i][j] = toCharge;
            }
        }
    }

    //keep configuration with the highest affinity
    int highestAffConfig = -1;
    double minAffinity = 1e10;
    double maxAffinity = -1e10;
    for(int i = 0; i < 1000; ++i) {

        SetChargeState(sitesList,trialConfigs[i]);
        double configAffinity = GetAffinity(sitesList, trialConfigs[i], affinity);

        if(configAffinity > maxAffinity) {
            highestAffConfig = i;
            maxAffinity = configAffinity;
        } else if(configAffinity < minAffinity) {
            minAffinity = configAffinity;
        }
    }

    if(highestAffConfig == -1) {
        cerr << "All affinities are less than -10^10. There must be a bug..." << endl;
        exit(-1);
    }


    cerr << "Lowest trial state affinity:  " << minAffinity << endl;
    cerr << "Highest trial state affinity: " << maxAffinity << endl;

    //Reset charges to the desired configuration
    SetChargeState(sitesList,trialConfigs[highestAffConfig]);

    //Copy desired configuration to be used for iterative moving
    int * resWithCharges = new int[charge];
    for(int j = 0; j < charge; ++j) {
        resWithCharges[j] = trialConfigs[highestAffConfig][j];
    }

	for (int i = 0; i < 1000; ++i) delete[] trialConfigs[i];

    double affPrev = maxAffinity;
	LinkedList<double> prevAffinities;
    prevAffinities.Append(affPrev);
    double highestAffinity = affPrev;
    int    * highAffConfig = new int[charge];
    for(int i = 0; i < charge; ++i) highAffConfig[i] = resWithCharges[i];
    cerr << "step:\t\t\t\t\tAvg. Affinity (last 25%)" << endl;
    //Iterate charge moving until converged
    int i = 0;
	int numZero = 0;
    while(++i) {
        if(i % 1000 == 0) cerr << "Computing " << i << "th step       \r";
        if(i == 3e7) break;
        //Change one charge site randomly
        int changeIdx  = rand() % charge;
        int changeSite = resWithCharges[changeIdx];
        int newSite    = rand() % numSites;
        for(int j = 0; j < charge; ++j) {
            //choose a new site if the site to be charged is already charged
            if(resWithCharges[j] == newSite) {
                newSite = rand() % numSites;
                j = -1;  //Will be incremented at end of loop (restart)
            }
        }

        sitesList[changeSite]->charge = 0;
        sitesList[newSite]->charge    = 1;
        resWithCharges[changeIdx] = newSite;
        
        //Calculate new affinity
        double newAffinity = GetAffinity(sitesList, resWithCharges, affinity);

        //keep a running tally of the "best" protonation state
        if(newAffinity > highestAffinity) {
            for(int j = 0; j < charge; ++j ) {
                highAffConfig[j] = resWithCharges[j];
            }
            highestAffinity = newAffinity;
        }

        //Metropolis-Hastings: accept with a probability if new affinity is lower than old one
		double check = (double) rand();
		if (check == 0) numZero++;
        if(newAffinity > affPrev || exp((newAffinity-affPrev)/RT) > check / RAND_MAX) {//(double) rand() / RAND_MAX) {
            //accept changes
            AtomInfo * oldAtom = sitesList[changeSite];
            AtomInfo * newAtom = sitesList[newSite];
            cerr << "Moving charge from atom #" << oldAtom->serial << " to atom #";
            cerr << newAtom->serial << "\t(" << newAffinity-affPrev << " change in affinity)" << (double) numZero/i << " " << check / RAND_MAX << endl;
            affPrev = newAffinity;
        } else {
            //revert changes to protonation
            sitesList[changeSite]->charge = 1;
            sitesList[newSite]->charge    = 0;
            resWithCharges[changeIdx]     = changeSite;
        }

        prevAffinities.Append(affPrev);
                
        //check for convergence every 10000 iterations after 800000
        if(i % 10000 == 0 && i >= 800000) {
            cerr << "\t\t\t\t\t" << Average(prevAffinities,(int)0.75*i,i) << endl;
            if(IsConverged(prevAffinities)) {
                cerr << endl << "Variance (as RT^2 fraction): ";
                cerr << CalcVariance(prevAffinities,(int)0.75*i,i)/RT/RT << " at step " << i << endl;
                break;
            }
        }
    }
    cerr << endl;
    cerr << "highest affinity configuration:" << endl;
    for(int j = 0; j < charge; ++j) {
        int res = highAffConfig[j];
        cerr << sitesList[res]->resName << " (#" << sitesList[res]->resSeq << ")" << endl;
    }
    cerr << endl << "Highest Affinity: " << highestAffinity << endl;

    SetChargeState(sitesList,highAffConfig);

	delete[] resWithCharges;
	delete[] highAffConfig;

    cerr << "Making an energy output file at " << energyFileName << endl;
    ofstream output;
    output.open(energyFileName.c_str());
    if(output.fail()) cerr << "could not open " << energyFileName << endl;
    Node<double> * n = prevAffinities.GetHead();
    int j = 0;
    while( n != NULL) {
        if(j % 100 != 0) {
            n = n->next; ++j;
            continue;
        }
        output << fixed << j << "," << n->value << endl;
        n = n->next; ++j;
    }
    output.close();
    cerr << endl << "finished outputting to energy file." << endl;
    cerr.unsetf( std::ios::fixed );
}

double ChargePlacer::GetAffinity(AtomInfo ** sitesList, int * resWithCharges, int * affinity) {

    int charge = (int) Parameters::Get()->GetCharge();

    double protonAff = 0;
    double chargeRepulsion = 0;
    //Affinity due to gas-phase proton affinity of charge sites
    for(int i = 0; i < charge; ++i) protonAff += affinity[resWithCharges[i]];

    //Affinity due to coulombic repulsion of charge sites
//    #pragma omp parallel for reduction(+:chargeRepulsion)
    for(int i = 0; i < charge-1; ++i) {
        for(int j = i+1; j < charge; ++j) {
            AtomInfo * n = sitesList[resWithCharges[i]];
            AtomInfo * m = sitesList[resWithCharges[j]];
            double distVec[3] = {n->x - m->x, n->y - m->y, n->z - m->z};
            double dist = sqrt(distVec[0]*distVec[0] + distVec[1]*distVec[1] + distVec[2]*distVec[2]);
            chargeRepulsion += enConst / (dist*Parameters::Get()->GetEpsilon()); //each site has one charge
        }
    }

    return protonAff-chargeRepulsion;
}

double ChargePlacer::Average(LinkedList<double> & energies,int start, int end) {
    double averageAffinity = 0;
    Node<double> * n = energies.GetTail();
    int position = energies.GetListLength()-1;
    int numAdded = 0;
    while(n) {
        if(position <= end && position >= start) {
            averageAffinity+=n->value/(end-start+1);
            ++numAdded;
        }
        if(position == start) break;
        n = n->prev;
        --position;
    }
    return averageAffinity;
}

double ChargePlacer::CalcVariance(LinkedList<double> & energies,int start, int end) {
    double avgAff = Average(energies,start,end);
    int position = energies.GetListLength()-1;
    double variance = 0;
    for(Node<double> * n = energies.GetTail(); n!=NULL; n = n->prev) {
        if(position <= end && position >= start) variance += (n->value-avgAff)*(n->value-avgAff)/(end-start+1);
        if(position==start) break;
        --position;
    }
    return variance;

}

void ChargePlacer::SetChargeState(AtomInfo ** sitesList, int * protSites) {
    //initialize with zero charge
    for(int j = 0; j < numSites; ++j) sitesList[j]->charge = 0;
    //charge the sites according to protSites
    for(int j = 0; j < Parameters::Get()->GetCharge(); ++j) sitesList[protSites[j]]->charge = 1;
}

bool ChargePlacer::IsConverged(LinkedList<double> & energies) {
    int numEnergies = energies.GetListLength()-1;
    double enChange = Average(energies,(int)floor(0.75*numEnergies),numEnergies)-Average(energies,(int)floor(0.5*numEnergies),(int)ceil(0.75*numEnergies));
    if(enChange >= 0 && enChange < 0.1*RT && CalcVariance(energies,(int)floor(0.75*numEnergies),numEnergies)<6*RT*6*RT) return true;
    return false;
}

int ChargePlacer::ReplaceCharges(Molecule * m) {

    if(!m->GetChainInfo()) {
        cerr << "Residue information not present, cannot place charges." << endl;
        return 0;
    }

    ostringstream charge_str;
    charge_str << Parameters::Get()->GetCharge();
    string coordFile = Parameters::Get()->GetCoordFileName();
    string outputFileName = coordFile.substr(0,coordFile.find_last_of(".")) + "_" + charge_str.str() + "+.pdb";

    cerr << "Deriving N-terminal info from coordinate file." << endl;

    numSites = GetNumSites(m);
    if(numSites == -1) return -1;

    AtomInfo ** sitesList = new AtomInfo*[numSites];
    int * affinity = new int[numSites];
    int nextSite = 0;

    for(int i = 0; i < m->GetNumAtoms(); ++i) {
        AtomInfo * curAtom = &m->GetAtoms()[i];
        curAtom->charge = 0;
        bool isNTerminus = true;

        //Only look at atoms named "N"
        if(curAtom->name != "N") continue;

        //If an N-terminus has been identified and atom has the same chainID and model,
        //then the atom is not an N-terminus
        for(int j = 0; j < nextSite; ++j) {
            if(curAtom->chainID == sitesList[j]->chainID && curAtom->model == sitesList[j]->model) {
                isNTerminus = false;
                break;
            }
        }
        if(!isNTerminus) continue;

        //Now it must be the lowest number resSeq in the chain
        for(int j = 0; j < m->GetNumAtoms(); ++j) {
            if(curAtom->chainID != m->GetAtoms()[j].chainID || curAtom->model != m->GetAtoms()[j].model) continue;
            if(curAtom->resSeq > m->GetAtoms()[j].resSeq) {
                isNTerminus = false;
                break;
            }
        }
        if(isNTerminus && nextSite <= numSites) { // Guard against segmentation fault
            sitesList[nextSite] = curAtom;
            affinity[nextSite] = 960000;
            ++nextSite;
        }
    }

    bool atomFound = false;
    string prevResName = m->GetAtoms()[0].resName;
    int prevResSeq = m->GetAtoms()[0].resSeq;
    for(int i = 0; i < m->GetNumAtoms(); ++i) {
        int aff = 0;
        string atomWanted;
        AtomInfo * curAtom = &m->GetAtoms()[i];

        if(prevResName != curAtom->resName || prevResSeq != curAtom->resSeq) {
            if(!atomFound) cerr << "Requested charge site on residue " << prevResName << " (#" << prevResSeq << ") not found - will not consider for charge placement." << endl;
            prevResName = curAtom->resName;
            prevResSeq  = curAtom->resSeq;
            atomFound = false;
        }
        ResAffMap::iterator it = affinities.find(curAtom->resName);
        if(it != affinities.end()) {
            atomWanted = it->second.first;
            aff   = it->second.second;
        } else {
            cerr << "unknown residue \"" << curAtom->resName << endl;
            return -1;
        }

        if(curAtom->name == atomWanted && nextSite <= numSites) { // Guard against segmentation faults
            if(atomFound) {
                cerr << "More than 1 charge site located on residue " << prevResName << " (#" << prevResSeq << ")";
                cerr  << ". Please change your naming so that there is one charge site per residue." << endl;
                return -1;
            }
            atomFound = true;
            affinity[nextSite] = aff;
            sitesList[nextSite] = curAtom;
            ++nextSite;
        }
    }

    cerr << "Found " << numSites << " charge sites on " << m->GetNumRes();
    cerr << " residues (" << numSites-m->GetNumRes();
    cerr<< " N-terminii)." << endl << endl;
    cerr << "Putting a +" << Parameters::Get()->GetCharge() << " charge on molecule." << endl;

    //MOVE CHARGES!
    Place(sitesList, affinity);

	delete[] affinity;
	delete[] sitesList;

    cerr << "Creating a new pdb file named " << outputFileName;
    cerr << ", which has " << Parameters::Get()->GetCharge() << " charges in it." << endl;

    PdbWriter pdbOutput(outputFileName.c_str());
    pdbOutput.SetAtomInfo(m);
    pdbOutput.Write();

    return 0;
}

int ChargePlacer::GetNumSites(Molecule * m) {
    int numSites = 0;
    AtomInfo ** tempSites = new AtomInfo*[m->GetNumRes()]; // Definitely no more N-terminii than residues
    int curAtomNum = 0;
    for(int i = 0; i < m->GetNumAtoms(); ++i) {
        AtomInfo * curAtom = &m->GetAtoms()[i];
        bool isNTerminus = true;

        //Only look at atoms named "N"
        if(curAtom->name != "N") continue;

        //If an N-terminus has been identified and atom has the same chainID and model,
        //then the atom is not an N-terminus
        for(int j = 0; j < curAtomNum; ++j) {
            if(curAtom->chainID == tempSites[j]->chainID && curAtom->model == tempSites[j]->model) {
                isNTerminus = false;
                break;
            }
        }
        if(!isNTerminus) continue;

        //Now it must be the lowest number resSeq in the chain
        for(int j = 0; j < m->GetNumAtoms(); ++j) {
            if(curAtom->chainID != m->GetAtoms()[j].chainID || curAtom->model != m->GetAtoms()[j].model) continue;
            if(curAtom->resSeq > m->GetAtoms()[j].resSeq) {
                isNTerminus = false;
                break;
            }
        }
        if(isNTerminus && curAtomNum <= m->GetNumRes()) { // Guard against segmentation fault
            ++numSites;
            tempSites[curAtomNum] = curAtom;
            ++curAtomNum;
        }
    }

	delete[] tempSites;

    // Check for 1 charge site per residue, based on the Affinity Input File
    string atomWanted;
    int aff = 0;
    for(int i = 0; i < m->GetNumAtoms(); ++i) {
        AtomInfo * curAtom = &m->GetAtoms()[i];

        ResAffMap::iterator it = affinities.find(curAtom->resName);
        if(it != affinities.end()) {
            atomWanted = it->second.first;
            aff   = it->second.second;
        } else {
            cerr << "unknown residue \"" << curAtom->resName << endl;
            return -1;
        }

        if(curAtom->name == atomWanted) ++numSites;
    }
    return numSites;
}

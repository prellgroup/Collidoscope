/************ CoordinateFileReader.h ************/
#ifndef COORDINATE_FILE_READER_H
#define COORDINATE_FILE_READER_H

#include "FileReader.h"         // Parent class
#include "CoordinateFileData.h" // AtomType

using namespace std;

class CoordinateFileReader : public FileReader {
  public:
                  CoordinateFileReader(string);
                 ~CoordinateFileReader();
    virtual bool  Read(); 
    bool          ReadPDB();
    bool          ReadMFJ();
    string        MFJMassToElement(int);
    bool          ReadTXT();
    AtomType      DetermineAtomType(string);
};

#endif

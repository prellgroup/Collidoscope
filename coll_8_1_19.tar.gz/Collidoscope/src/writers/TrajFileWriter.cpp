/*************** TrajFileWriter.cpp **************/
#include "TrajFileWriter.h"
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>           // exit

using namespace std;

TrajFileWriter::TrajFileWriter(string fileName,int numThreads) {
    separateTrajFiles = new string[numThreads];
    traj              = new stringstream[numThreads];
    this -> fileName  = fileName;
    for(int i = 0;i<numThreads;++i) {
        char tmpFile[128];
        snprintf(tmpFile,128,"%s-%d",fileName.c_str(),i);
        separateTrajFiles[i] = tmpFile;
    }
}

TrajFileWriter::~TrajFileWriter() {
    if(separateTrajFiles != NULL) delete [] separateTrajFiles;
    if(traj              != NULL) delete [] traj;
}

void TrajFileWriter::AppendToTraj(double * pos,int i) {
    if(!(traj[i] << "{" << pos[0] << "," << pos[1] << "," << pos[2] << "}\t")) {
        cerr << "could not append to trajectory!" << endl;
        exit(-1);
    }
}

void TrajFileWriter::ClearTraj(int i) {
    traj[i].str("");
}

void TrajFileWriter::Write() {}

void TrajFileWriter::Write(int i) {
    ofstream trajFile;
    trajFile.open(separateTrajFiles[i].c_str(),ios_base::app);
    trajFile << traj[i].str() << endl;
    trajFile.close();    
}

void TrajFileWriter::Combine(int numThreads) {
    ofstream trajectory;
    cerr << "Removing/combining temporary trajectory files: " << endl;
        
    trajectory.open(fileName.c_str());
    for(int i=0;i<numThreads;++i) {
        cerr << "\t" << separateTrajFiles[i] << endl;
        ifstream tmptrajfile;
        tmptrajfile.open(separateTrajFiles[i].c_str());
        if(!tmptrajfile) continue;
        string fileLine;
        while(!tmptrajfile.eof()) {
            getline(tmptrajfile,fileLine);
            trajectory << fileLine << endl;
        }
        tmptrajfile.close();
        remove(separateTrajFiles[i].c_str());
    }
    cerr << "done" << endl;
    trajectory.close();

}

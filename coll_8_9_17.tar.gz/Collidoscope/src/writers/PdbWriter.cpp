/*************** PdbWriter.cpp ****************/
#include "PdbWriter.h"
#include <fstream>      // ofstream
#include <iomanip>      // setw

using namespace std;

PdbWriter::PdbWriter(string fileName) : Writer(fileName) {
    m = NULL;
};

void PdbWriter::Write() {
    if(m != NULL) {
        ofstream pdbOutput;
        pdbOutput.open(fileName.c_str());
        int curModel = -1;
        for(int i = 0; i < m->GetNumAtoms(); ++i) {
            AtomInfo * curAtom = &m->GetAtoms()[i];
            if(curAtom->model != curModel) {
                if(curModel != -1) pdbOutput << "ENDMDL" << endl;
                curModel = curAtom->model;
                pdbOutput << "MODEL     " << setw(4) << curModel << endl;
            }
            pdbOutput << "ATOM  " << setw(5) << m->GetAtoms()[i].serial << " ";
            pdbOutput << setw(4) << m->GetAtoms()[i].name << " ";
            pdbOutput << setw(3) << m->GetAtoms()[i].resName << " ";
            pdbOutput <<            m->GetAtoms()[i].chainID;
            pdbOutput << setw(4) << m->GetAtoms()[i].resSeq << "    ";
            pdbOutput << setw(8) << m->GetAtoms()[i].x;
            pdbOutput << setw(8) << m->GetAtoms()[i].y;
            pdbOutput << setw(8) << m->GetAtoms()[i].z << "                      ";
            pdbOutput << setw(2) << m->GetAtoms()[i].element;
            if(m->GetAtoms()[i].charge<0) pdbOutput << -m->GetAtoms()[i].charge << "-" << endl;
            else if(m->GetAtoms()[i].charge>0) pdbOutput << m->GetAtoms()[i].charge << "+" << endl;
            else pdbOutput << "  " << endl;
        }
        pdbOutput << "ENDMDL";
        pdbOutput.close();
    }
}

void PdbWriter::SetAtomInfo(Molecule * m) {
    this -> m = m;
}

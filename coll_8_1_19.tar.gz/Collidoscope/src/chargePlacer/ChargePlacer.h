/*************** ChargeMover.h ****************/
#ifndef CHARGE_MOVER_H
#define CHARGE_MOVER_H

#include "LinkedList.h"              // Custom Linked List data type
#include "CoordinateFileData.h"    // AtomInfo data type
#include "AffinityFileData.h"
#include "Molecule.h"
#include <map>                       // map structure

using namespace std;

class ChargePlacer {
  private:
    static ChargePlacer * instance;
    map<string, std::pair<string,int> > affinities;
    double              * prevEnergies;
    static double         enConst;
    static double         RT;
    int                   numSites;
  public:
                         ~ChargePlacer();
    static ChargePlacer * Get();
    void                  SetMoleculeInfo(CoordinateFileData*);
    void                  Place(AtomInfo**,int*);
    double                GetAffinity(AtomInfo**,int*,int*);
    double                CalcVariance(LinkedList<double>&,int,int);
    double                Average(LinkedList<double>&,int,int);
    void                  SetChargeState(AtomInfo**,int*);
    bool                  IsConverged(LinkedList<double>&);
    int                   ReplaceCharges(Molecule*);
    void                  SetAffinities(AffinityFileData*);
    CoordinateFileData  * GetPdb();
    int                   GetNumSites(Molecule*);
};

#endif

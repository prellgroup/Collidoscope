/********** FileReader.h *************/
#ifndef FILE_READER_H
#define FILE_READER_H

#include "FileData.h"
#include <string>

using namespace std;

class FileReader {
  protected:
    FileData     * output;
    string         fileName;
  public:
                   FileReader(std::string);
                  ~FileReader();
    virtual bool   Read() = 0;
    FileData     * GetOutput();
};

#endif

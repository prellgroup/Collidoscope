/********** DiatomicParticleReader.h ************/
#ifndef DIATOMIC_PARTICLE_READER_H
#define DIATOMIC_PARTICLE_READER_H

#include "GasFileReader.h"
#include <string>

using namespace std;

class DiatomicParticleReader: public GasFileReader {
  public:
         DiatomicParticleReader(string);
        ~DiatomicParticleReader();
    bool Read();
};

#endif

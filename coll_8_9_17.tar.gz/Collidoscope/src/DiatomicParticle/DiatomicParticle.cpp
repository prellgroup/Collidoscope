/***********DiatomicParticle.cpp*************/
#include "DiatomicParticle.h"
#include "DiatomicParticleData.h"
#include "System.h"
#include <cmath>         // pow, sqrt

#include <iostream>

#include <cstdio>

using namespace std;

DiatomicParticle::DiatomicParticle() : Particle() {
    mass = 4.002602;           //molar mass in kg/mol
}

double DiatomicParticle::FindPotential(double * pos) {
    double potDir[3];
    for(int i = 0; i < 3; ++i) {
        double dir[3];
        for(int j = 0; j < 3; ++j) dir[j] = (i == j);
        potDir[i] = FindPotentialDir(pos, dir);
    }

    return (potDir[0] + potDir[1] + potDir[2])/3;
}

double DiatomicParticle::FindPotentialDir(double * pos, double * dir) {

    // Find rotation matrix components
    double ctheta = dir[2]; // theta is the z-axis declination angle
    double stheta = sqrt(dir[0]*dir[0]+dir[1]*dir[1]);
    double cphi; // phi is the xy-plane rotation angle
    double sphi;
    if(stheta == 0) {
        cphi = 0;
        sphi = 1;
    } else {
        cphi = dir[0]/stheta;
        sphi = dir[1]/stheta;
    }

    // Rotation matrix
    double R[3][3];
    R[0][0] = cphi*stheta;
    R[0][1] = -stheta*sphi;
    R[0][2] = ctheta;
    R[1][0] = sphi;
    R[1][1] = cphi;
    R[1][2] = 0;
    R[2][0] = -ctheta*cphi;
    R[2][1] = ctheta*sphi;
    R[2][2] = stheta;

    Molecule * mol      = System::Get()->m;
    double * atomPos    = mol->GetAtomPos();
    double * atomCharge = mol->GetAtomCharge();
    double * energy     = mol->GetAtomEnergy();
    double * rMin       = mol->GetAtomRmin();
    double potential = 0;
    // One atom on each side of the center of the bond
    for(double offset = -1.0/2; offset < 1; offset++) {
    //for(double offset = -bondLength/2; offset < bondLength; offset += bondLength) {
//    for(int N = -1; N<2; N+=2) {

        double curPos[3] = {pos[0]+offset*bondLength*dir[0], pos[1]+offset*bondLength*dir[1], pos[2]+offset*bondLength*dir[2]};
//        double curPos[3] = {pos[0]+N*bondLength/2*dir[0], pos[1]+N*bondLength/2*dir[1], pos[2]+N*bondLength/2*dir[2]};



        for(int atom = 0; atom < mol->GetNumAtoms(); ++atom) {
            double dist[3]    = {curPos[0]-atomPos[3*atom+0],
                                 curPos[1]-atomPos[3*atom+1],
                                 curPos[2]-atomPos[3*atom+2]};
            double rSq        = dist[0]*dist[0] + dist[1]*dist[1] + dist[2]*dist[2];

            if(rSq > 0.00001) { // Any smaller could cause overflows
                // LJ 6-12 terms
                double r6Term     = pow(rMin[atom]*rMin[atom]/rSq, 3);
                potential += energy[atom] * (r6Term*r6Term - 2*r6Term);
            } else potential += 1e50;
        }
    }

    // Add polarizability potential
    // First, determine the electric field at the center of mass of the particle
    double E[3];
    for(int i = 0; i < 3; ++i) {
        E[i] = 0;
    }
    for(int atom = 0; atom < mol->GetNumAtoms(); ++atom) {
        double dist[3]    = {pos[0]-atomPos[3*atom+0],
                             pos[1]-atomPos[3*atom+1],
                             pos[2]-atomPos[3*atom+2]};
        double rSq        = dist[0]*dist[0] + dist[1]*dist[1] + dist[2]*dist[2];

        if(atomCharge[atom] != 0) {
            double rCub = sqrt(rSq)*rSq;
            for(int i = 0; i < 3; ++i) E[i] += dist[i]*atomCharge[atom]/rCub;
        }

    }

    // Add E field from any charge at the center of mass
    if( mol->GetCOMCharge() != 0) {
        double rCub = sqrt(toCenterSq)*toCenterSq;
        // electric field in units of m^-2*10^20
        for(int i = 0; i < 3; ++i) E[i] += pos[i]*mol->GetCOMCharge()/rCub;
    }

    // U=-1/2*E^T*R^T*alpha*R*E is the matrix equation for the potential
    double pol[3] = {axialPol, radialPol, radialPol};
    for(int k = 0; k < 3; ++k) {
        for(int j = 0; j < 3; ++j) {
            for(int i = 0; i < 3; ++i) {
                potential -= C4Const/2*E[k]*R[j][k]*pol[j]*R[j][i]*E[i];
            }
        }
    }

    return potential;
}

// Potential of mean force
void DiatomicParticle::FindForce() {
    double potDir[3];
    for(int i = 0; i < 3; ++i) {
        force[i] = 0;
        potDir[i] = 0;
    }
    double * forceDir[3];
    for(int i = 0; i < 3; ++i) {
        double dir[3];
        // align with axes
        for(int j = 0; j < 3; ++j) dir[j] = (i == j);
        forceDir[i] = FindForceDir(dir, &potDir[i]);
    }

    double partFunc = 0;
    for(int i = 0; i < 3; ++i) partFunc += exp(-potDir[i]/System::Get()->RT);

    for(int i = 0; i < 3; ++i) {
        for(int j = 0; j < 3; ++j) {
            force[i] += exp(-potDir[j]/System::Get()->RT)*forceDir[j][i]/partFunc;
        }
    }

    for(int i = 0; i < 3; ++i) delete forceDir[i];
}

double * DiatomicParticle::FindForceDir(double * dir, double * potDir) {

    // Find rotation matrix components
    double ctheta = dir[2]; // theta is the z-axis declination angle
    double stheta = sqrt(dir[0]*dir[0]+dir[1]*dir[1]);
    double cphi; // phi is the xy-plane rotation angle
    double sphi;
    if(stheta == 0) {
        cphi = 0;
        sphi = 1;
    } else {
        cphi = dir[0]/stheta;
        sphi = dir[1]/stheta;
    }

    // Rotation matrix
    double R[3][3];
    R[0][0] = cphi*stheta;
    R[0][1] = -stheta*sphi;
    R[0][2] = ctheta;
    R[1][0] = sphi;
    R[1][1] = cphi;
    R[1][2] = 0;
    R[2][0] = -ctheta*cphi;
    R[2][1] = ctheta*sphi;
    R[2][2] = stheta;

    double * forceDir = new double[3];
    for(int i = 0; i < 3; ++i) forceDir[i] = 0;
    Molecule * mol = System::Get()->m;
    double * atomPos    = mol->GetAtomPos();
    double * atomCharge = mol->GetAtomCharge();
    double * energy     = mol->GetAtomEnergy();
    double * rMin       = mol->GetAtomRmin();

    // LJ potential and force applies to each atom in the particle
    for(double offset = -0.5; offset < 1; offset++) {

        int atom = offset < 0; // <0 is first atom, >0 is second atom
        double curPos[3] = {pos[0]+offset*bondLength*dir[0], pos[1]+offset*bondLength*dir[1], pos[2]+offset*bondLength*dir[2]};

        for(int m = 0; m < mol->GetNumAtoms(); ++m){ //loop over coordinates of all atoms in scattering center to get acceleration
            double distance[3] = {curPos[0]-atomPos[3*m+0],
                                  curPos[1]-atomPos[3*m+1],
                                  curPos[2]-atomPos[3*m+2]};

            double rSq      = distance[0]*distance[0] + distance[1]*distance[1] + distance[2]*distance[2];

            //LJ 6-12 force
            double rmin6_r8 = pow(rMin[m]/rSq, 4) * rMin[m] * rMin[m];
            double forceConstant = energy[m] * (rmin6_r8*rmin6_r8*rSq - rmin6_r8);
            for(int i = 0; i < 3; ++i) forceDir[i] += 12*forceConstant*distance[i];

            // LJ 6-12 potential
            double r6Term   = rmin6_r8 * rSq;
            *potDir         += energy[m] * (r6Term*r6Term - 2*r6Term);

        }
    }

    // Electric field vector and gradient
    double E[3];
    double dE[3][3];

    for(int j = 0; j < 3; ++j) {
        E[j] = 0;
        for(int k = 0; k < 3; ++k) dE[j][k] = 0;
    }

    // Determine charge effects
    double  pol[3]  = {axialPol,radialPol,radialPol};
    for(int m = 0; m < mol->GetNumAtoms(); ++m) {
        if(atomCharge[m]!=0) {
            double distance[3] = {pos[0]-atomPos[3*m+0],
                                  pos[1]-atomPos[3*m+1],
                                  pos[2]-atomPos[3*m+2]};

            double rSq  = distance[0]*distance[0] + distance[1]*distance[1] + distance[2]*distance[2];
            double rCub = sqrt(rSq)*rSq;
            for(int i = 0; i < 3; ++i) {
                //electric Field: units are m^-2*10^20
                E[i] += distance[i]*atomCharge[m]/rCub;
                //Vector gradient of field in m^-3*10^30
                for(int j = 0; j < 3; ++j) {
                    dE[i][j] -= 3*atomCharge[m]*distance[i]*distance[j]/(rCub*rSq);
                    if(i == j) dE[i][j] += atomCharge[m]/rCub;
                }
            }
        }
    }

    // add any contribution from charge at the center of mass, if it is present
    if(mol->GetCOMCharge() != 0) {
        double rCub = sqrt(toCenterSq)*toCenterSq;
        for(int i = 0; i < 3; ++i) {
            //electric Field: units are m^-2*10^20
            E[i] += pos[i]*mol->GetCOMCharge()/rCub;
            //Vector gradient of field in m^-3*10^30
            for(int j = 0; j < 3; ++j) {
                dE[i][j] -= 3*mol->GetCOMCharge()*pos[i]*pos[j]/(rCub*toCenterSq);
                if(i == j) dE[i][j] += mol->GetCOMCharge()/rCub;
            }
        }

    }

    // Store additional (redundant) information
    dE[1][0] = dE[0][1];
    dE[2][0] = dE[0][2];
    dE[2][1] = dE[1][2];

    //C4 ion-induced dipole force
    double polVec[3] = {0,0,0};
    for(int k = 0; k < 3; ++k) {
        for(int j = 0; j < 3; ++j) {
            for(int i = 0; i < 3; ++i) {
                polVec[k] += R[j][k]*pol[j]*R[j][i]*E[i];
            }
        }
    }

    for(int l = 0; l < 3; ++l) {
        for(int k = 0; k < 3; ++k) {
            forceDir[l] += C4Const*dE[l][k]*polVec[k];
        }
        *potDir -= C4Const/2*E[l]*polVec[l];
    }
    return forceDir;
}

void DiatomicParticle::SetInfo(GasFileData * gas) {
    DiatomicParticleData * info = (DiatomicParticleData *) gas;
    this->axialPol = info->axialPol;
    this->radialPol = info->radialPol;
    this->bondLength = info->bondLength;
}

double DiatomicParticle::GetPol() {
    return axialPol;
}

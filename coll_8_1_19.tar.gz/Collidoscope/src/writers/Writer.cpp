/************* Writer.cpp ************/
#include "Writer.h"
#include <string>

using namespace std;

Writer::Writer() {}
Writer::Writer(string fileName) {
    this -> fileName = fileName;
}

/********* Definitions.h ************/
#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#if defined(_WIN32)
  #include <windows.h>
  #include <Shlwapi.h>
  #define ON_WINDOWS
#elif defined(__unix__) || defined (__unix)
  #include <unistd.h>
  #define ON_LINUX
#endif

#endif
/************* Parameters.h **************/
#ifndef PARAMETERS_H
#define PARAMETERS_H

#include "FileData.h"
#include <bitset>             //bitset container

using namespace std;

// To be used as flags in a bitset
enum SettingsFileContents {
    CHARGE,
    MINEN,
    MAXEN,
    ENSTATES,
    TEMP,
    PTYPE,
    INTEGRATOR,
    COORDNAME,
    INFONAME,
    TRAJNAME,
    TRAJSETTING,
    MODE,
    EPSILON,
    ENERGYNAME,
    GEOMETRYNAME,
    AFFINITYNAME,
    SETTINGSNAME,
    GASNAME
};

enum ParticleType {
    PT_SPHERICAL,
    PT_DIATOMIC,
    PT_UNKNOWN
};

enum TrajOutput {
    TO_OUTPUT,
    TO_COMBINED,
    TO_UNKNOWN
};

enum AlgorithmMode {
    ALG_CHARGE_PLACER,
    ALG_CROSS_SECTION,
    ALG_UNKNOWN
};

enum IntegrationMethod {
    IM_EULER,
    IM_RK4,
    IM_UNKNOWN
};

class Parameters : public FileData {
  private:
    static Parameters * instance;
    bitset<18>          settingsPresent;
    bitset<3>           trajSetting;
    bitset<3>           mode;
    string              settingsFileName;
    string              geometryFileName;
    string              affinityFileName;
    string              gasParamFileName;
    double              charge;
    double              minEn;
    double              maxEn;
    int                 enStates;
    double              temp;
    ParticleType        pType;
    IntegrationMethod   method;
    string              coordFileName;
    string              infoFileName;
    string              trajFileName;
    double              epsilon;
    string              energyFileName;
  public:
    static Parameters * Get();
                      Parameters();
                     ~Parameters();
    void              DetermineIntegrationMethod(string);
    void              DetermineParticleType(string);
    bool              ChangeFileNames();
    int               GetAppendNum(string);
    bool              FileExists(string);
    void              DetermineTrajOutput(string);
    void              SetMode(string);
    string            GetpTypeString();
    string            GetMethodString();
    string            GetTrajSettingString();
    string            GetModeString();
    bool              SetFromCommandLine(int,char**);
    bool              AreValid();
    bitset<18>      & GetSettingsPresent();
    bitset<3>       & GetTrajSetting();
    bitset<3>       & GetMode();
    string          & GetSettingsFileName();
    string          & GetGeometryFileName();
    string          & GetAffinityFileName();
    string          & GetGasParamFileName();
    double          & GetCharge();
    double          & GetMinEn();
    double          & GetMaxEn();
    int             & GetEnStates();
    double          & GetTemp();
    ParticleType      GetPType();
    IntegrationMethod GetMethod();
    string          & GetCoordFileName();
    string          & GetInfoFileName();
    string          & GetTrajFileName();
    double          & GetEpsilon();
    string          & GetEnergyFileName();
};

#endif

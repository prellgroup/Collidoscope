#ifndef STRING_MANIP_H
#define STRING_MANIP_H

#include <string>

using namespace std;

string CleanString(string&);
string ToLower(string);
bool   isNumeric(const char*);
bool   ExtractIntAfter(string,string,int&);
bool   ExtractDoubleAfter(string,string,double&);
//bool   ExtractStringAfter(string,string,string&);
bool   ParseStringBefore(string&,char,string&);
bool   ParseStringAfter(string&,char,string&);
#endif

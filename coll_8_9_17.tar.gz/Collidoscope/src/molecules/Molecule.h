/*************Molecule.h****************/
#ifndef MOLECULE_H
#define MOLECULE_H

#include "GasFileData.h"
#include "CoordinateFileData.h"    // For AtomInfo struct and argument to constructor

using namespace std;

class Molecule {
  private:
    double                 totCharge;      // elementary charges
    double                 COMCharge;      // elementary charges
    double                 rMax;           // angstroms
    double                 mass;           // g/mol
    double                 COM[3];         // angstroms
    int                    numAtoms;       // unitless
    double                 inertia;        // kg*m^2
    double               * atomMass;       // kg
    double               * atomPos;        // angstroms
    double               * atomCharge;     // elementary charges
    double               * atomRmin;       // angstroms
    double               * atomEnergy;     // joules
    AtomInfo             * atoms;
    int                    numRes;
    int                    numChains;
    bool                   chainInfo;
  public:
                           Molecule(CoordinateFileData*);
                          ~Molecule();
    void                   Print();  //Used for debugging
    void                   ReCenter();
    double                 GetRmax() const;
    double                 GetMass() const;
    double               * GetCOM();
    int                    GetNumAtoms() const;
    double               * GetAtomPos() const;
    double                 GetTotCharge() const;
    void                   SetCharge(double);
    double                 GetInertia() const;
    double               * GetAtomMass() const;
    double               * GetAtomRmin() const;
    double               * GetAtomEnergy() const;
    double               * GetAtomCharge() const;
    double               & GetCOMCharge();
    bool                   SetAtomProperties(GasFileData*);
    void                   SetCharges();
    AtomInfo             * GetAtoms();
    int                    GetNumRes();
    bool                   GetChainInfo();
};

#endif

/********** AffinityFileReader.h ************/
#ifndef AFFINITY_FILE_READER_H
#define AFFINITY_FILE_READER_H

#include "FileReader.h"

using namespace std;

class AffinityFileReader : public FileReader {
  public:
                 AffinityFileReader(string);
                ~AffinityFileReader();
    virtual bool Read();
};

#endif

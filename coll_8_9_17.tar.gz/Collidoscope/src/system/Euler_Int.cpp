/************ Euler_Int.cpp ************/
#include "Euler_Int.h"
#include "System.h"

using namespace std;

void Euler_Int::Update(Particle * p, double dt) {
    
    double * v     = p->GetVel();
    double * pos   = p->GetPos();
    double * force = p->GetForce();
    double mu      = System::Get()->mu;

    p->FindForce();

    v[0]   += dt/mu * force[0];
    v[1]   += dt/mu * force[1];
    v[2]   += dt/mu * force[2];

    pos[0] += dt*v[0];
    pos[1] += dt*v[1];
    pos[2] += dt*v[2];

    p->SetToCenterSq(pos[0]*pos[0] + pos[1]*pos[1] + pos[2]*pos[2]);
}

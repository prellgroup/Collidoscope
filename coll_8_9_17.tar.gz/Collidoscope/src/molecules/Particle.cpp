/***********Particle.cpp*************/
#include "Particle.h"

using namespace std;

// C4Const is multiplied by 10^40, since 1 N*m^2/mol is 10^40 in units of N*m^2/mol * 10^-40
double Particle::C4Const  = 1.389355815e36;    //k*e*e*Na*10^40 (N*m^2/mol *10^-40) (k is coulomb's constant)
double Particle::k        = 1.38064852e-23;   // J/K

Particle::Particle() {
    skipped = false;
}

void Particle::SetPos(double * pos) {
    this -> pos[0] = pos[0];
    this -> pos[1] = pos[1];
    this -> pos[2] = pos[2];
    toCenterSq = pos[0]*pos[0] + pos[1]*pos[1] + pos[2]*pos[2];    
}

double * Particle::GetPos() {
    return pos;
}

double * Particle::GetVel() {
    return v;
}

void Particle::SetVel(double * vel) {
    v[0] = vel[0];
    v[1] = vel[1];
    v[2] = vel[2];
}

double Particle::GetToCenterSq() {
    return toCenterSq;
}

void Particle::SetToCenterSq(double toCenterSq) {
    this -> toCenterSq = toCenterSq;
}

void Particle::SetEnStateIdx(int idx) {
    enStateIdx = idx;
}

int Particle::GetEnStateIdx() {
    return enStateIdx;
}

double Particle::GetEnRatio() {
    return enRatio;
}

void Particle::SetEnRatio(double ratio) {
    enRatio = ratio;
}

int Particle::GetSteps() {
    return steps;
}

void Particle::SetSteps(int steps) {
    this->steps = steps;
}

double * Particle::GetForce() {
    return force;
}

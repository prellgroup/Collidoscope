/************* GasFileReader.h *************/
#ifndef GAS_FILE_READER_H
#define GAS_FILE_READER_H

#include "FileReader.h"

using namespace std;

class GasFileReader : public FileReader {
  public:
                 GasFileReader();
                 GasFileReader(string);
    virtual bool Read() = 0;
};

#endif

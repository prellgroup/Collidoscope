/************ RK4_Int.cpp ************/
#include "RK4_Int.h"
#include "System.h"

using namespace std;

double RK4_Int::pathDist[4] = {0, 1/2, 1/2, 1};
double RK4_Int::weight[4]   = {1/6, 1/3, 1/3, 1/6};

void RK4_Int::Update(Particle * p, double dt) {
    
    double * v     = p->GetVel();
    double * pos   = p->GetPos();
    double * force = p->GetForce();

    double initPos[3] = {pos[0], pos[1], pos[2]};
    double initVel[3] = {v[0], v[1], v[2]};
    double length[3]  = {1/2,1/2,1};
    double mass       = System::Get()->mu;

    double k[4][3]; // related to dv
    double l[4][3]; // related to dr

    p->FindForce();

    k[0][0] = dt*force[0]/mass;
    k[0][1] = dt*force[1]/mass;
    k[0][2] = dt*force[2]/mass;

    l[0][0] = dt*v[0];
    l[0][1] = dt*v[1];
    l[0][2] = dt*v[2];


    for(int i = 1; i < 4; ++i) {
        pos[0] = initPos[0] + l[i-1][0]*length[i-1];
        pos[1] = initPos[1] + l[i-1][1]*length[i-1];
        pos[2] = initPos[2] + l[i-1][2]*length[i-1];

        p->FindForce();

        k[i][0] = dt*force[0]/mass;
        k[i][1] = dt*force[1]/mass;
        k[i][2] = dt*force[2]/mass;

        l[i][0] = dt*(v[0]+k[i-1][0]*length[i-1]);
        l[i][1] = dt*(v[1]+k[i-1][1]*length[i-1]);
        l[i][2] = dt*(v[2]+k[i-1][2]*length[i-1]);
    }

    // Finalize pos and v
    pos[0] = initPos[0] + (l[0][0]+2*l[1][0]+2*l[2][0]+l[3][0])/6;
    pos[1] = initPos[1] + (l[0][1]+2*l[1][1]+2*l[2][1]+l[3][1])/6;
    pos[2] = initPos[2] + (l[0][2]+2*l[1][2]+2*l[2][2]+l[3][2])/6;

    v[0]   = initVel[0] + (k[0][0]+2*k[1][0]+2*k[2][0]+k[3][0])/6;
    v[1]   = initVel[1] + (k[0][1]+2*k[1][1]+2*k[2][1]+k[3][1])/6;
    v[2]   = initVel[2] + (k[0][2]+2*k[1][2]+2*k[2][2]+k[3][2])/6;
    
    p->SetToCenterSq(pos[0]*pos[0] + pos[1]*pos[1] + pos[2]*pos[2]);
}

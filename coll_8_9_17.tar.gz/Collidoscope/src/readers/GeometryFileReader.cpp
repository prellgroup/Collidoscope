/************* GeometryFileReader.cpp *************/
#include "GeometryFileReader.h"
#include "GeometryFileData.h"
#include <fstream>              // ifstream
#include <iostream>             // cerr, endl
#include <cmath>                // sqrt

GeometryFileReader::GeometryFileReader(string fileName) : FileReader(fileName) {
    output = new GeometryFileData;
};

GeometryFileReader::~GeometryFileReader() {
    //cerr << "deleting Geometry File Reader" << endl;
    if(((GeometryFileData*) output)->vantages != NULL) delete [] ((GeometryFileData*) output)->vantages;
    if(output != NULL) delete output;
}

bool GeometryFileReader::Read() {
    GeometryFileData * VP = (GeometryFileData*) output;
    ifstream geo;
    geo.open(fileName.c_str());
    if(!geo) {
        cerr << "Geometry Input File " << fileName << " did not open." << endl;
        return false;
    }
    
    VP->vantagePoints = 0;
    //Read in number of vantagepoints -- all vantagepoints present will be used
    string line;
    std::getline(geo, line);
    while(!geo.eof()) {
        ++VP->vantagePoints;
        std::getline(geo,line);
    }

    if(VP->vantagePoints == 0) {
        cerr << fileName << " is an empty file. Please choose a Geometry Input File that contains vantage points." << endl;
        return false;
    }

    if(VP->vantagePoints < 15) {
        cerr << "Using only " << VP->vantagePoints << " vantage points. Use more to ensure spherical symmetry." << endl;
    }

    geo.clear();
    geo.seekg(0);

    VP->vantages = new double[VP->vantagePoints*3];     //The direction of each set of incoming particles
    for(int i = 0; i < VP->vantagePoints; ++i) {
        geo >> VP->vantages[3*i+0];
        geo >> VP->vantages[3*i+1];
        geo >> VP->vantages[3*i+2];
    }

    //Normalize the vantage point vectors
    for(int i = 0; i < VP->vantagePoints; ++i) {
        double * vPi = &VP->vantages[3*i];
        double vPLength = sqrt(vPi[0]*vPi[0]+vPi[1]*vPi[1]+vPi[2]*vPi[2]);
        vPi[0] /= vPLength;
        vPi[1] /= vPLength;
        vPi[2] /= vPLength;
    }

    geo.close();
    return true;
}

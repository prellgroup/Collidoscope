#include "CoordinateFileReader.h"
#include <iostream>   // cerr
#include <string>     // string, find, substr
#include <cstdlib>    // exit
#include <cmath>      // log10, abs, ceil
#include <iomanip>    // setw
#include <fstream>    // ofstream
#include <algorithm>  // max

using namespace std;

int digBeforeDec(double num) {
    int a = max(1,(int)ceil(abs(log10(abs(num)))));
    if(num<0) ++a; //has a "-" before decimal
    return a;
}

int main(int argc, char ** argv) {

    if(argc < 2) {
        cerr << "USAGE: ./txt2pdb path_to_txt_file" << endl;
        exit(-1);
    }

    string inputFileName   = argv[1];
    string outputFileName  = inputFileName.substr(0,inputFileName.find("."));
    outputFileName        += ".pdb";
    
    CoordinateFileReader coord(inputFileName);
    coord.Read();
    CoordinateFileData * txtData = (CoordinateFileData*) coord.GetOutput();

    ofstream pdbOutputFile;
    pdbOutputFile.open(outputFileName.c_str());
    for(int i = 0; i < txtData->numAtoms; ++i) {
        pdbOutputFile << "ATOM                          ";
        pdbOutputFile << setw(8) << setprecision(7-digBeforeDec(txtData->atomList[i].x)) << txtData->atomList[i].x;
        pdbOutputFile << setw(8) << setprecision(7-digBeforeDec(txtData->atomList[i].y)) << txtData->atomList[i].y;
        pdbOutputFile << setw(8) << setprecision(7-digBeforeDec(txtData->atomList[i].z)) << txtData->atomList[i].z;
        pdbOutputFile << "                      ";
        pdbOutputFile << setw(2) << txtData->atomList[i].element;
        //currently, charges have to be >=0
        txtData->atomList[i].charge=round(txtData->atomList[i].charge);
        if(txtData->atomList[i].charge<0) pdbOutputFile << -txtData->atomList[i].charge << "-" << endl;
        else if(txtData->atomList[i].charge>0) pdbOutputFile << txtData->atomList[i].charge << "+" << endl;
        else pdbOutputFile << endl;
    }
    pdbOutputFile.close();
}

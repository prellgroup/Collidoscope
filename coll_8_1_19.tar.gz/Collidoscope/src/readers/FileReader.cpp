/************ FileReader.cpp *************/
#include "FileReader.h"
#include <iostream>

using namespace std;

FileReader::FileReader(string fileName) {
    this -> fileName = fileName;
    output = NULL;
}

FileReader::~FileReader() {
    //cerr << "deleting a file reader of some sort..." << endl;
}

FileData * FileReader::GetOutput() {
    return output;
}

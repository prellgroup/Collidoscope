/************ EnergyState.h ***********/
#ifndef ENERGY_STATE_H
#define ENERGY_STATE_H

class EnergyState {
  public:
    double         EnKinInit;
    double         speed;
    double         timestep;
                   ~EnergyState();
    void           SetEnParams(double);
    void           CreateVantagePoints(int,double*,double*,double*);
    double         GetWeighting(int);
    void           Print();
};

#endif

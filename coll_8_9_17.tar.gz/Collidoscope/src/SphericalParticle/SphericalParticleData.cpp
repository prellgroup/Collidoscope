/*************** SphericalParticleData.cpp *************/
#include "SphericalParticleData.h"

using namespace std;

GasFileData * SphericalParticleData::Copy() {
    SphericalParticleData * newObj = new SphericalParticleData;
    newObj->pol  = this->pol;
    newObj->mass = this->mass;
    newObj->data = this->data;
    return newObj;
}

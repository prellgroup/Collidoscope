/************* AffinityFileData.h **************/
#ifndef AFFINITY_FILE_DATA_H
#define AFFINITY_FILE_DATA_H

#include "FileData.h"
#include <map>

using namespace std;

typedef std::map<string, std::pair<string,int> > ResAffMap;

class AffinityFileData : public FileData {
  public:
    ResAffMap data;
};

#endif

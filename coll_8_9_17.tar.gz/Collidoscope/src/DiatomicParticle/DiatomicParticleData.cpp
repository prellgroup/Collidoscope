/*************** DiatomicParticleData.cpp *************/
#include "DiatomicParticleData.h"
#include <iostream>
#include <cstdio>

using namespace std;

GasFileData * DiatomicParticleData::Copy() {
    DiatomicParticleData * newObj = new DiatomicParticleData;
    newObj->axialPol  = axialPol;
    newObj->bondLength = this->bondLength;
    newObj->radialPol = this->radialPol;
    newObj->mass = this->mass;
    newObj->data = this->data;
    return newObj;
}

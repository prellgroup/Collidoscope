/******* Particle.h ********/
#ifndef PARTICLE_H
#define PARTICLE_H

#include "GasFileData.h"

using namespace std;

class Particle {
  protected:
    static double  k;            //Boltzmann's constant
    static double  C4Const;      //N*m^2/mol *10^40
    double         mass;           //kg/mol
    int            enStateIdx;
    double         toCenterSq;   //angstroms
    double         v[3];         // m/s
    double         pos[3];       //angstroms
    double         force[3];     // N/mol * 10^10
    bool           skipped;
    double         enRatio;
    int            steps;
  public:
                   Particle();
    virtual       ~Particle() {};
    double       * GetPos();
    double       * GetVel();
    double         GetToCenterSq();
    void           SetToCenterSq(double);
    void           SetPos(double*);
    void           SetVel(double*);
    virtual void   FindForce() = 0;
    virtual double FindPotential(double*) = 0;
    double         GetrminSq();
    virtual void   SetInfo(GasFileData*) = 0;
    void           SetEnStateIdx(int);
    int            GetEnStateIdx();
    void           SetEnRatio(double);
    double         GetEnRatio();
    int            GetSteps();
    void           SetSteps(int);
    double       * GetForce();
};

#endif

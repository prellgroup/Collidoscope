/************* GasFileData.h **************/
#ifndef GAS_FILE_DATA_H
#define GAS_FILE_DATA_H

#include "FileData.h"
#include <string>
#include <map>

using namespace std;

typedef std::pair<double,std::pair<double,double> > MoleculeAtom;
typedef std::map<string, MoleculeAtom> LJMap;

//Each atom in the molecule has 3 associated doubles: rMin, epsilon, and mass
inline MoleculeAtom Atom(double d1, double d2, double d3) {
    return MoleculeAtom(d1, std::pair<double,double>(d2,d3));
}

class GasFileData : public FileData {
  public:
    virtual GasFileData * Copy();
            LJMap         data;
            double        mass;
};

#endif

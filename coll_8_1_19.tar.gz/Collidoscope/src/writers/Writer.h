/*********** Writer.h *************/
#ifndef WRITER_H
#define WRITER_H

#include <string>

using namespace std;

class Writer {
  protected:
    string       fileName;
  public:
                 Writer(std::string);
                 Writer();
    virtual void Write() = 0;
};

#endif

/********Molecule.cpp*************/
#include "Molecule.h"
#include "Parameters.h"
#include "StringManip.h"
#include <cmath>         // sqrt
#include <iostream>      // cerr, endl
#include <algorithm>     // max

using namespace std;

Molecule::Molecule(CoordinateFileData * coord) {
    atomMass   = NULL;
    atomRmin   = NULL;
    atomEnergy = NULL;
    totCharge  = Parameters::Get()->GetCharge();

    //copy values in CoordinateFileData to the molecule
    numAtoms   = coord->numAtoms;
    numRes     = coord->numRes;
    numChains  = coord->numChains;
    chainInfo  = coord->chainInfo;
    atomPos    = new double[3*numAtoms];
    atomCharge = new double[numAtoms];
    atoms      = new AtomInfo[numAtoms];

    for( int i = 0; i < numAtoms; ++i) {
        atoms[i]       = coord->atomList[i];
        atomPos[3*i+0] = atoms[i].x;
        atomPos[3*i+1] = atoms[i].y;
        atomPos[3*i+2] = atoms[i].z;
    }

    SetCharges();
}

Molecule::~Molecule() {
    //cerr << "deleting the molecule" << endl;
    if (atomMass   != NULL) delete [] atomMass;
    if (atomRmin   != NULL) delete [] atomRmin;
    if (atomEnergy != NULL) delete [] atomEnergy;
    if (atomPos    != NULL) delete [] atomPos;
    if (atomCharge != NULL) delete [] atomCharge;
    if (atoms      != NULL) delete [] atoms;
}

bool Molecule::SetAtomProperties(GasFileData * gas) {
    //create lists of the correct length to fill below
    atomMass   = new double[numAtoms];
    atomRmin   = new double[numAtoms];
    atomEnergy = new double[numAtoms];

    // In case of error initialize to zero
    for(int i = 0; i < numAtoms; ++i) {
        atomMass[i]   = 0;
        atomRmin[i]   = 0;
        atomEnergy[i] = 0;
    }

    mass        = 0;
    COM[0]      = 0;
    COM[1]      = 0;
    COM[2]      = 0;

    for(int i = 0; i < numAtoms; ++i) {
        LJMap::iterator it;
        for(it = gas->data.begin(); it != gas->data.end(); ++it) {
            if( it->first == ToLower(atoms[i].element)) {
                atomRmin[i]   = it->second.first;
                atomEnergy[i] = it->second.second.first;
                atomMass[i]   = it->second.second.second;
                break;
            }
        }
        if(it == gas->data.end()) {
            cerr << "Atom #" << atoms[i].serial << "(" << atoms[i].name << ",";
            cerr << atoms[i].element << ")" << " has no Lennard-Jones parameters specified." << endl;
            return false;
        }
        mass   += atomMass[i];
        COM[0] += atomMass[i]*atomPos[3*i+0];
        COM[1] += atomMass[i]*atomPos[3*i+1];
        COM[2] += atomMass[i]*atomPos[3*i+2];
    }
    COM[0] /= mass;
    COM[1] /= mass;
    COM[2] /= mass;
    ReCenter();
    return true;
}

void Molecule::SetCharges() {
    double totAtomCharge = 0;

    for( int i = 0; i < numAtoms; ++i) {
        atomCharge[i]  = atoms[i].charge;
        totAtomCharge += atomCharge[i];
    }

    COMCharge = totCharge - totAtomCharge;
}

//Used for debugging
void Molecule::Print() {
    for(int i = 0; i < numAtoms; ++i) {
        cerr << "atomMass[" << i << "] = " << atomMass[i] << endl;
        cerr << "atomPos[" << 3*i+0 << "] = " << atomPos[3*i+0] << endl;
        cerr << "atomPos[" << 3*i+1 << "] = " << atomPos[3*i+1] << endl;
        cerr << "atomPos[" << 3*i+2 << "] = " << atomPos[3*i+2] << endl;
        cerr << "atomCharge[" << i << "] = " << atomCharge[i] << endl;
        cerr << endl;
    
        if(i == numAtoms-1) {
            cerr << "rMax = " << rMax << endl;
            cerr << "mass = " << mass << endl;
            cerr << "COM[0] = " << COM[0] << endl;
            cerr << "COM[1] = " << COM[1] << endl;
            cerr << "COM[2] = " << COM[2] << endl;
            cerr << "totCharge = " << totCharge << endl;
            cerr << "COMCharge = " << COMCharge << endl;
            cerr << "numAtoms  = " << numAtoms << endl;
        }
    }
}

void Molecule::ReCenter() {
    double rMaxSq = 0;
    double rSq    = 0;
    inertia       = 0;
    for(int i = 0; i < numAtoms; ++i) {
        atomPos[3*i+0] -= COM[0];
        atomPos[3*i+1] -= COM[1];
        atomPos[3*i+2] -= COM[2];
        rSq      = atomPos[3*i+0]*atomPos[3*i+0]
                 + atomPos[3*i+1]*atomPos[3*i+1]
                 + atomPos[3*i+2]*atomPos[3*i+2];
        inertia += atomMass[i]*rSq;
        rMaxSq   = max(rMaxSq,rSq);
    }
    inertia /= 6.02e46;    //Convert to SI units
    rMax     = sqrt(rMaxSq);
}

double Molecule::GetRmax() const {
    return rMax;
}

double Molecule::GetMass() const {
    return mass;
}

double * Molecule::GetCOM() {
    return COM;
}

int Molecule::GetNumAtoms() const {
    return numAtoms;
}

double * Molecule::GetAtomPos() const {
    return atomPos;
}

double Molecule::GetTotCharge() const {
    return totCharge;
}

double Molecule::GetInertia() const {
    return inertia;
}

double * Molecule::GetAtomMass() const {
    return atomMass;
}

double * Molecule::GetAtomRmin() const {
    return atomRmin;
}

double * Molecule::GetAtomEnergy() const {
    return atomEnergy;
}

double * Molecule::GetAtomCharge() const {
    return atomCharge;
}

double & Molecule::GetCOMCharge() {
    return COMCharge;
}

AtomInfo * Molecule::GetAtoms() {
    return atoms;
}

int Molecule::GetNumRes() {
    return numRes;
}

bool Molecule::GetChainInfo() {
    return chainInfo;
}

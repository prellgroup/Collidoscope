/************** GasFileReader.cpp **************/
#include "GasFileReader.h"

using namespace std;

GasFileReader::GasFileReader(string fileName) : FileReader(fileName) {};

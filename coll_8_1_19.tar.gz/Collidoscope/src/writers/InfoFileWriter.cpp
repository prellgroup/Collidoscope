/*********** InfoFileWriter.cpp ***********/
#include "InfoFileWriter.h"
#include "System.h"
#include "Molecule.h"
#include "Parameters.h"
#include "GeometryFileData.h"
#include <string>
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

char InfoFileWriter::version[64] = "1.4 - Physics - 8/9/17";   // Version of the program being run

InfoFileWriter::InfoFileWriter(string fileName) : Writer(fileName) {}

void InfoFileWriter::WriteHeader() {
    Parameters * params = Parameters::Get();
    System     * sys    = System::Get();
    Molecule   * mol    = sys->GetMolecule();
    double     * molCOM = mol->GetCOM();

    ofstream output;
    output.open(fileName.c_str(),std::ofstream::app);

    output << "Parameters used:" << endl;
    output << "#\tSettings Input File      : " << params->GetSettingsFileName() << endl;
    output << "\tAlgorithm                : " << params->GetModeString() << endl;
    output << "\tInformation Output File  : " << params->GetInfoFileName() << endl;
    output << "\tCoordinate Input File    : " << params->GetCoordFileName() << endl;
    output << "#\tNumber of atoms          = " << mol->GetNumAtoms() << endl;
    output << "\tNet Charge               = " << params->GetCharge() << endl;
    output << "\tTemperature              = " << params->GetTemp() << endl;

    if(params->GetMode().test(ALG_CHARGE_PLACER)) {
        output << "\tEpsilon                  = " << params->GetEpsilon() << endl;
        output << "\tEnergy Output File       : " << params->GetEnergyFileName() << endl;
        output << "\tAffinity Input File      : " << params->GetAffinityFileName() << endl;
    }

    if(params->GetMode().test(ALG_CROSS_SECTION)) {
        output << "\tParticle Type            : " << params->GetpTypeString() << endl;
        output << "\tIntegration Method       : " << params->GetMethodString() << endl;
        output << "\tGas Parameter Input File : " << params->GetGasParamFileName() << endl;
        output << "\tTrajectory output setting: " << params->GetTrajSettingString() << endl;
        if(Parameters::Get()->GetTrajSetting().test(TO_OUTPUT)) output << "\tTrajectory output file  :  " << params->GetTrajFileName() << endl;
        output << "\tGeometry Input File      : " << params->GetGeometryFileName() << endl;
        output << "#\tVantage Points           = " << System::Get()->numVantages << endl;
        output << "\tMinimum Energy           = " << params->GetMinEn() << endl;
        output << "\tMaximum Energy           = " << params->GetMaxEn() << endl;
        output << "\tEnergy states            = " << params->GetEnStates() << endl;
        output << endl;
        output << "\tDerived information:" << endl;
        output << "\tRadius of trajectories   = " << System::Get()->bMax << " Angstroms" << endl;
        output << "\tMolecular mass           = " << mol->GetMass() << " g/mol" << endl;
        output << "\tMu                       = " << System::Get()->mu << " kg/mol" << endl;
        output << "\tMoment of Inertia        = " << mol->GetInertia() << " kg*m^2" << endl;
        output << "\tCenter of Mass           = {" << molCOM[0] << "," << molCOM[1] << "," << molCOM[2] << "} Angstroms" << endl;
        output << "\timpact parameter spacing = " << System::Get()->dist << " Angstroms" << endl << endl;
    }
    output << endl;
    output.close();
}

void InfoFileWriter::WriteCrossSectionResults() {
    System     * sys     = System::Get();
    Summary    * summary = sys->s;

    ofstream output;
    output.open(fileName.c_str(),std::ofstream::app);

    output << "CCS SUMMARY:" << endl;
    for(int i = 0; i < Parameters::Get()->GetEnStates(); ++i) {
        output << "\tEnergy state #" << i+1 << endl;
        output << "\t\tInitial Kinetic Energy   : " << sys->ES[i].EnKinInit << " RT" << endl;
        output << "\t\tInitial Timestep         : " << sys->ES[i].timestep/10 << " ns" << endl;
        output << "\t\tAverage Cross Section    : " << summary->enStateAvgCS[i] << " square angstroms" << endl;
        output << endl;
        output << "\t\tMin. Energy Conservation : " << summary->enRatioMin[i] << endl;
        output << "\t\tMax. Energy Conservation : " << summary->enRatioMax[i] << endl;
        output << "\t\tAvg. Energy Conservation : " << summary->enRatioAvg[i] << endl;
        output << "\t\tStdev Energy Conservation: " << summary->enRatioStdev[i] << endl;
        output << endl;
        output << "\t\tTotal Trajectories       : " << sys->totTrajectories/Parameters::Get()->GetEnStates() << endl;
        output << "\t\tSuccessful Trajectories  : " << summary->enStateSuccess[i] << endl;
        output << "\t\tSkipped Trajectories     : " << summary->enStateSkipped[i] << endl;
        output << "\t\tRerun Trajectories       : " << summary->enStateRerun[i] << endl;
        output << "\t\tOmitted Trajectories     : " << summary->enStateOmitted[i] << endl;
        output << endl;
        output << "\t\tMaximum timesteps        : " << summary->stepsMax[i] << endl;
        output << "\t\tMinimum timesteps        : " << summary->stepsMin[i] << endl;
        output << "\t\tAverage timesteps        : " << summary->stepsAvg[i] << endl;
        output << endl;

    }
    output << endl;
    output << "Program Version: " << version << endl;
    output << "Number of trajectories rerun         : " << sys->totRerun << endl;
    output << "Number of successful trajectories    : " << sys->totSuccess << endl;
    output << "Number of skipped trajectories       : " << sys->totSkipped << endl;
    output << "Number of failed/omitted trajectories: " << sys->totOmitted << endl;
    output << "Total Avg. Collisional Cross Section : " << sys->crossSection << " square angstroms " << endl;
    output << "Program time: " << wallTime << " s wall; " << cpuTime << " s CPU" << endl;
}

void InfoFileWriter::WriteChargePlacerResults() {
    ofstream output;
    output.open(fileName.c_str(),std::ofstream::app);

    output << "CHARGE PLACEMENT RESULTS:" << endl;
}

void InfoFileWriter::SetTimes(double wallTime, double cpuTime) {
    this -> wallTime = wallTime;
    this -> cpuTime  = cpuTime;
}

void InfoFileWriter::Write() {
    WriteHeader();
    if(Parameters::Get()->GetMode().test(ALG_CHARGE_PLACER)) WriteChargePlacerResults();
    if(Parameters::Get()->GetMode().test(ALG_CROSS_SECTION)) WriteCrossSectionResults();

};

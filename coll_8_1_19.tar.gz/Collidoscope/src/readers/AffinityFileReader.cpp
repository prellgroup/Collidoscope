/************* AffinityFileReader.cpp *************/
#include "AffinityFileReader.h" // Function declarations
#include "AffinityFileData.h"   // AffinityFileData data type
#include "StringManip.h"        // CleanString, ToLower
#include <algorithm>            // remove_if
#include <cctype>               // isspace, tolower
#include <fstream>              // ifstream
#include <iostream>             // fail, cerr
#include <string>               // find, npos, substr, erase, c_str
#include <cstring>              // size_t, strcmp
#include <sstream>              // stringstream

AffinityFileReader::AffinityFileReader(string fileName) : FileReader(fileName) {
    output = new AffinityFileData;
};

AffinityFileReader::~AffinityFileReader() {
    //cerr << "deleting affinity reader" << endl;
    delete output;
}

//Read each line of the fileName file, storing to variables as needed
bool AffinityFileReader::Read() {
    AffinityFileData * out = (AffinityFileData*) output;
    ifstream inputFile;
    inputFile.open(fileName.c_str());
    if(inputFile.fail()) {
        cerr << "Affinity Input File " << fileName << " did not open." << endl;
        return false;;
    }

    string line;
    getline(inputFile,line);
    string lowerCaseLine = ToLower(line);
    while(!inputFile.eof()) {
        if(line[0] == '#' || line == "") {
            getline(inputFile,line);
            lowerCaseLine = ToLower(line);
            continue;
        }
        string keepLine = line;

        string res, atomWanted, aff_string;
        if(!ParseStringBefore(res,'|',line) || !ParseStringBefore(atomWanted,'|',line)) {
            cerr << "Misformatted line in " << fileName << ": " << keepLine << endl;
            return false;
        }
        CleanString(res);
        CleanString(atomWanted);
        aff_string = CleanString(line);
        if(!isNumeric(aff_string.c_str())) {
            cerr << "In " << fileName << " line \"" << keepLine << "\", affinity must be a number." << endl;
            return false;
        }
        int aff = atoi(aff_string.c_str());

        if(out->data.find(res) != out->data.end()) {
            fprintf(stderr,"Duplicate residue in %s: %s\n", fileName.c_str(), res.c_str());
        } else {
            out->data.insert(std::pair<string,std::pair<string,int> >(res, std::pair<string,int>(atomWanted, aff)));
        }

        getline(inputFile,line);
        lowerCaseLine = ToLower(line);
    }
    inputFile.close();
    return true;
}

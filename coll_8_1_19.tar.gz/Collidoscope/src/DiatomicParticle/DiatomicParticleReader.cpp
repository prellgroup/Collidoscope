/************* DiatomicParticleReader.cpp *************/
#include "DiatomicParticleReader.h"      // Function declarations
#include "DiatomicParticleData.h"        // GasFileData data type
#include "StringManip.h"        // ToLower, CleanString
#include <algorithm>            // remove_if
#include <cctype>               // isspace, tolower
#include <fstream>              // ifstream
#include <iostream>             // fail, cerr
#include <string>               // find, npos, substr, erase, c_str
#include <cstring>              // size_t, strcmp
#include <sstream>              // stringstream

using namespace std;

DiatomicParticleReader::DiatomicParticleReader(string fileName) : GasFileReader(fileName) {
    output = new DiatomicParticleData;
    ((DiatomicParticleData*) output)->axialPol = 0;
    ((DiatomicParticleData*) output)->radialPol = 0;
    ((DiatomicParticleData*) output)->mass = 0;
};

DiatomicParticleReader::~DiatomicParticleReader() {
    //cerr << "deleting Lennard-Jones reader" << endl;
    //delete output;
}

//Read each line of the fileName file, storing to variables as needed
bool DiatomicParticleReader::Read() {
    DiatomicParticleData * out = (DiatomicParticleData*) output;
    ifstream inputFile;
    inputFile.open(fileName.c_str());
    if(inputFile.fail()) {
        cerr << "Lennard-Jones Input File " << fileName << " did not open." << endl;
        return false;
    }

    string line;
    getline(inputFile,line);
    string lowerCaseLine = ToLower(line);
    bool massPresent = false;
    bool axialPolPresent  = false;
    bool radialPolPresent = false;
    bool bondLengthPresent = false;
    while(!inputFile.eof()) {
        double mass = 0;
        double rMin = 0;
        double epsilon = 0;
        if(line[0] == '#' || line == "") {
            getline(inputFile,line);
            lowerCaseLine = ToLower(line);
            continue;
        }

        if(!massPresent && lowerCaseLine.find("mass") != string::npos) {
            if(!ExtractDoubleAfter("=", line, out->mass)) {
                cerr << "In " << fileName << ", mass must be a number." << endl;
                return false;
            }
            massPresent = true;
        } else if(!axialPolPresent && lowerCaseLine.find("polarizability (axial)") != string::npos) {
            if(!ExtractDoubleAfter("=", line, out->axialPol)) {
                cerr << "In " << fileName << ", polarizability must be a number." << endl;
                return false;
            }
            axialPolPresent = true;
        } else if(!radialPolPresent && lowerCaseLine.find("polarizability (radial)") != string::npos) {
            if(!ExtractDoubleAfter("=", line, out->radialPol)) {
                cerr << "In " << fileName << ", polarizability must be a number." << endl;
                return false;
            }
            radialPolPresent = true;
        } else if(!bondLengthPresent && lowerCaseLine.find("bond length") != string::npos) {
            if(!ExtractDoubleAfter("=", line, out->bondLength)) {
                cerr << "In " << fileName << ", bond length must be a number." << endl;
                return false;
            }
            bondLengthPresent = true;
        } else {
            line = ToLower(line);
            string atom, rMin_str, eps_str, mass_str;
            ParseStringBefore(atom,'|',line);
            ParseStringBefore(rMin_str,'|',line);
            ParseStringBefore(eps_str,'|',line);
            mass_str = line;
            CleanString(atom);
            CleanString(rMin_str);
            CleanString(eps_str);
            CleanString(mass_str);

            if(!isNumeric(rMin_str.c_str())) {
                cerr << "rMin for atom " << atom << " in Lennard Jones File \"" << fileName;
                cerr << "\" is not a number: " << rMin_str << endl;
                return false;
            } else {
                rMin = atof(rMin_str.c_str());
            }
            if(!isNumeric(eps_str.c_str())) {
                cerr << "epsilon for atom " << atom << " in Lennard Jones File \"" << fileName;
                cerr << "\" is not a number: " << eps_str << endl;
                return false;
            } else {
                epsilon = atof(eps_str.c_str());
            }
            if(!isNumeric(mass_str.c_str())) {
                cerr << "mass for atom " << atom << " in Lennard Jones File \"" << fileName;
                cerr << "\" is not a number: " << mass_str << endl;
                return false;
            } else {
                mass = atof(mass_str.c_str());
            }
        
            if(out->data.find(atom) != out->data.end()) {
                cerr << "Duplicate Lennard Jones option in " << fileName << ": " << atom << " will be ignored." << endl;
            } else {
                out->data[atom] = Atom(rMin, epsilon, mass);
            }
        }

        getline(inputFile,line);
        lowerCaseLine = ToLower(line);
    }
    if(!massPresent) {
        cerr << "Gas Particle Properties Input File " << fileName << " must contain the particle's mass." << endl;
        return false;
    }
    if(!radialPolPresent) {
        cerr << "Gas Particle Properties Input File " << fileName << " must contain the particle's radial polarizability." << endl;
        return false;
    }
    if(!axialPolPresent) {
        cerr << "Gas Particle Properties Input File " << fileName << " must contain the particle's axial polarizability." << endl;
        return false;
    }
    if(!bondLengthPresent) {
        cerr << "Gas Particle Properties Input File " << fileName << " must contain the particle's bond length." << endl;
        return false;
    }
    inputFile.close();
    return true;
}

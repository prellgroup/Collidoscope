/************** System.h ***********/
#ifndef SYSTEM_H
#define SYSTEM_H

#include "EnergyState.h"
#include "VantagePoint.h"
#include "Molecule.h"
#include "Particle.h"

#include "GasFileData.h"
#include "CoordinateFileData.h"
#include "GeometryFileData.h"

using namespace std;

struct TrajSummary {
    bool   trajSuccess;
    bool   trajRerun;
    bool   trajOmitted;
    double enRatio;
    int    timeSteps;
    double cosChi;
};

struct Summary {
    double * enStateAvgCS;
    int    * enStateSuccess;
    int    * enStateSkipped;
    int    * enStateRerun;
    int    * enStateOmitted;
    double * enRatioAvg;
    double * enRatioMax;
    double * enRatioMin;
    double * enRatioStdev;
    double * enRatioSumSq;
    double * stepsAvg;
    int    * stepsMax;
    int    * stepsMin;
};

class System {
  private:
    static System     * instance;
  public:
    //Constants
    const static double R;
    const static double rCarbon;

    //Parameters from settings file
    double              minVel;
    double              maxVel;
    double              deltaVel;

    //results from settings file parameters
    double              mu;
    double              bMax;
    double              RT;
    double              dist;
    int                 numTraj;
    int                 totNumTraj1D;
    int                 totNumTraj2D;
    int                 totTrajectories;
    int                 totNumParticles;
    EnergyState       * ES;

    //other input file information
    int                 numVantages;
    VantagePoint      * VP;
    Molecule          * m;
    int               * partInt;
    GasFileData       * partInfo;

    //trajectory information
    int                 totRerun;
    int                 totSuccess;
    int                 totSkipped;
    int                 totOmitted;
    int                 numThreads;
    double              crossSection;
    Summary           * s;
    TrajSummary       * TS;

    //Functions
                        System();
                       ~System();
    static System     * Get();
    void                SetParams();
    void                AddMolecule(CoordinateFileData*);
    void                CreateVantagePoints(GeometryFileData*);
    void                Print();
    void                DeriveInformation();
    Molecule          * GetMolecule();
    void                outputPercentage(string);
    double              GetCrossSection();
    bool                SeedParticles();
    void                UpdateParticle(Particle*,double,double*);
    Summary           * GetSummary();
    void                Summarize();
    void                RotateMolecule(double, double);
    void                DeleteSummary();
    void                CreateSummary();
    bool                SetMoleculeProperties(GasFileData*);
    bool                WillNotSkip(Particle*);
    void                Reduce_MPI();
};

#endif

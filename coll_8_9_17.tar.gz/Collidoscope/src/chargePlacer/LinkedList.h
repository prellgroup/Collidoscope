/************ LinkedList.h *****************/
#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include "Node.h"     //Node data type

template <class T>
class LinkedList {
  private:
    Node<T> * head;
    Node<T> * tail;
    int       listLength;
  public:
              LinkedList();
              ~LinkedList();
    int       GetListLength();
    Node<T> * GetHead();
    Node<T> * GetTail();
    void      Append(T);
    void      Remove(int);
    void      Print();
    Node<T> * GetElement(int);
};

#include "LinkedList.tpp"    //function definitions

#endif

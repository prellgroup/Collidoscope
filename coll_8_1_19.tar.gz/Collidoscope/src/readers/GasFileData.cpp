/************** GasFileData.cpp ***************/
#include "GasFileData.h"

using namespace std;

GasFileData * GasFileData::Copy() {
    GasFileData * newObj = new GasFileData;
    newObj->data = this->data;
    return newObj;
}

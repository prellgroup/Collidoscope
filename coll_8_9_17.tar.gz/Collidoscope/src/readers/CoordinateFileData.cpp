/************** CoordinateFileData.cpp *****************/
#include "CoordinateFileData.h"
#include <iostream>

using namespace std;

CoordinateFileData::CoordinateFileData() {
    atomList = NULL;
}

CoordinateFileData::~CoordinateFileData() {
    //cerr << "deleting the Coordinate File Data" << endl;
    if(atomList != NULL) delete [] atomList;
    atomList = NULL;
}

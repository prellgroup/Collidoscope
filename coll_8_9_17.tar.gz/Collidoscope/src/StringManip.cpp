/************* StringManip.cpp ***************/
#include "StringManip.h"
#include <algorithm>            // remove_if
#include <cctype>               // isspace, tolower, isdigit
#include <cstring>              // strlen
#include <iostream>

using namespace std;

string ToLower(string line) {
    for(unsigned int i = 0; i < line.size(); ++i) line[i] = tolower(line[i]);
    return line;
}

//removes "whitespace characters' (\t, \n, ' ', etc.) from a string
string CleanString(string & str) {
    str.erase(remove_if(str.begin(), str.end(), ::isspace),str.end());
    return str;
}

//Return true if the string corresponds to a decimal number (+ or -, scientific notation)
bool isNumeric(const char * string) {
    for(unsigned int i = 0; i < strlen(string); ++i) {
        if(!isdigit(string[i]) && string[i] != '.' && string[i] != '-') {
            //check scientific notation, #e# or #E#
            if(string[i] == 'e' || string[i] == 'E') {
                if(i == 0 || i == strlen(string)-1) return false;
                if(isdigit(string[i-1]) && isdigit(string[i+1])) continue;
            }
            return false;
        }
    }
    return true;
}

//extract a double after delimChar
bool ExtractDoubleAfter(string delimChar, string line, double &data) {
    size_t delim = line.find(delimChar);
    if(delim != string::npos) {
        data = atof(line.substr(delim+1, string::npos).c_str());
        return true;
    }
    return false;
}

//Extract an integer after delimChar
bool ExtractIntAfter(string delimChar, string line, int &data) {
    size_t delim = line.find(delimChar);
    if(delim != string::npos) {
        data = atoi(line.substr(delim+1, string::npos).c_str());
        return true;
    }
    return false;
}

bool ParseStringBefore(string & output, char delim, string & input) {
    size_t split = input.find(delim);
    if(split != string::npos) {
        output = input.substr(0, split);
        input.erase(0, split+1);
        return true;
    }
    return false;
}

bool ParseStringAfter(string & input, char delim, string & output) {
    size_t split = input.find(delim);
    if(split != string::npos) {
        output = input.substr(split+1, string::npos);
        input.erase(split, string::npos);
        return true;
    }
    return false;
}

/********** SettingsFileReader.h ************/
#ifndef SETTINGS_FILE_READER_H
#define SETTINGS_FILE_READER_H

#include "FileReader.h"

class SettingsFileReader : public FileReader {
  public:
                 SettingsFileReader(string);
                ~SettingsFileReader();
    void         DetermineParticleType(string);
    void         DetermineIntegrationMethod(string);
    bool         ExtractDouble(string,string,double&);
    bool         ExtractInt(string,string,int&);
    bool         ExtractString(string,string,string&);
    virtual bool Read();
};

#endif

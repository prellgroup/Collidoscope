#include "StringManip.h"

using namespace std;

int main() {
    if(ToLower("TeSt") != "test" || ToLower("test") != "test") return -1;
    return 1;
}

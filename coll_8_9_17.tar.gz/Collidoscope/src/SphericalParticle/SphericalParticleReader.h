/********** SphericalParticleReader.h ************/
#ifndef SPHERICAL_PARTICLE_READER_H
#define SPHERICAL_PARTICLE_READER_H

#include "GasFileReader.h"
#include <string>

using namespace std;

class SphericalParticleReader: public GasFileReader {
  public:
         SphericalParticleReader(string);
        ~SphericalParticleReader();
    bool Read();
};

#endif

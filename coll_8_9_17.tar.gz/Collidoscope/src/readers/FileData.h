/*********** FileData.h **********/
#ifndef FILE_DATA_H
#define FILE_DATA_H

class FileData {};

#endif

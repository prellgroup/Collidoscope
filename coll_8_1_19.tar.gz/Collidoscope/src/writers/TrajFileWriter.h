/************** InfoFileWriter.h ************/
#ifndef TRAJ_FILE_WRITER_H
#define TRAJ_FILE_WRITER_H

#include "Writer.h"
#include <sstream>
#include <string>

using namespace std;

class TrajFileWriter : public Writer {
  public:
                   TrajFileWriter(string,int);
                   ~TrajFileWriter();
    void           SetTrajFile(string);
    stringstream * traj;
    string       * separateTrajFiles;
    bool           outputTraj;
    void           AppendToTraj(double*,int);
    void           ClearTraj(int);
    virtual void   Write();
    virtual void   Write(int);
    void           Combine(int);
};

#endif

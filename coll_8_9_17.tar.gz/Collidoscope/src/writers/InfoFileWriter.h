/************** InfoFileWriter.h ************/
#ifndef INFO_FILE_WRITER_H
#define INFO_FILE_WRITER_H

#include "Writer.h"
#include "System.h"
#include "Parameters.h"
#include "GeometryFileData.h"
#include "System.h"
#include <string>

using namespace std;

class InfoFileWriter : public Writer {
  protected:
    Parameters         * params;
    GeometryFileData   * VP;
    System             * s;
    Summary            * summary;
    static char          version[64];
    double               wallTime;
    double               cpuTime;
  public:
    bool                 outputTraj;
                         InfoFileWriter(std::string);
    virtual void         Write();
    void                 WriteHeader();
    void                 WriteChargePlacerResults();
    void                 WriteCrossSectionResults();
    void                 SetTimes(double,double);
};

#endif

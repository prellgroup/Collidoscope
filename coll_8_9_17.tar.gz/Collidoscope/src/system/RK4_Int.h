/************* RK4_Int.h **************/
#ifndef RK4_INT_H
#define RK4_INT_H

#include "Integrator.h"

using namespace std;

class RK4_Int : public Integrator {
  private:
    static double pathDist[4];
    static double weight[4];
  public:
    virtual void Update(Particle*,double);
};

#endif
